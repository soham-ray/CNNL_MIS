// DeleteModal.tsx

import React from "react";
import { Button, Modal, Typography } from "@mui/material";
import { Box } from "@mui/system";

interface DeleteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
}

const DeleteModal: React.FC<DeleteModalProps> = ({
  isOpen,
  onClose,
  onConfirm,
  title,
  message,
}) => {
  return (
    <Modal open={isOpen} onClose={onClose}>
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: 400,
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 4,
        }}
      >
        <div className="modal">
          <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
            {title}
          </Typography>
          <Typography variant="body1" sx={{ marginBottom: 2 }}>
            {message}
          </Typography>
          <div className="flex justify-end mt-4">
            <Button onClick={onClose} color="primary">
              Cancel
            </Button>
            <Button onClick={onConfirm} color="error">
              Delete
            </Button>
          </div>
        </div>
      </Box>
    </Modal>
  );
};

export default DeleteModal;

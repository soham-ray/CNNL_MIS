import React, { useEffect, useState } from "react";
import { Box, Button, Modal, ThemeProvider, Typography } from "@mui/material";
import { DataGrid, GridColDef, GridRowId } from "@mui/x-data-grid";
import { BASE_API_URL } from "API/Base";
import { format, parseISO } from "date-fns";

import { CDAccDetails, WrapTextCellProps } from "types";
import axios from "axios";
import theme from "theme";
import SearchInput from "Components/SearchInput";
import AxiosInstance from "API/axios";

export const formatDate = (dateString: string | null) => {
  if (!dateString) {
    return "N/A"; // or some default value
  }

  const date = parseISO(dateString);
  return format(date, "M/dd/yyyy h:mm:ss a");
};

interface CDAccDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectedCDAcc: (selectedCP: any) => void;
}

const CDAccDataModal: React.FC<CDAccDataModalProps> = ({
  isOpen,
  onClose,
  onSelectedCDAcc,
}) => {
  const [cdAccData, setcdAccData] = useState<any>([]);
  const [searchValue, setSearchValue] = useState<string>("");

  const fetchPageData = async () => {
    try {
      const response = await AxiosInstance.get(
        `${BASE_API_URL}/admin/v1/get-cd-account-details`
      );
      const data: CDAccDetails[] = response.data;
      setcdAccData(data);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchPageData();
    }
  }, [isOpen]);

  const columns: GridColDef[] = [
    { field: "Id", headerName: "ID", width: 50 },
    {
      field: "CD_Account",
      headerName: "CD Account",
      width: 100,
      renderCell: (params) => <WrapTextCell value={params.value} />,
    },
    {
      field: "Customer_Id",
      headerName: "Customer Id",
      width: 100,
      renderCell: (params) => <WrapTextCell value={params.value} />,
    },
    {
      field: "CD_Amount",
      headerName: "CD Amount",
      width: 100,
    },

    {
      field: "CD_Received",
      headerName: "CD Received",
      width: 100,
    },
    {
      field: "CD_Consume",
      headerName: "CD Consume",
      width: 100,
    },
    {
      field: "Created_On",
      headerName: "Created On",
      width: 160,
      valueFormatter: (params) => formatDate(params.value as string),
    },

    { field: "Modify_By", headerName: "Modified By", width: 160 },
  ];

  const handleRowSelection = (rowSelectionModel: GridRowId[]) => {
    const selectedRowId =
      rowSelectionModel.length > 0 ? rowSelectionModel[0].toString() : null;

    const selectedData = selectedRowId
      ? cdAccData.find((row: any) => row.Id === parseInt(selectedRowId, 10))
      : null;

    // Ensure selectedData is not null before logging the whole row data
    if (selectedData !== null && selectedData !== undefined) {
      // Pass both selectedCity and selectedData to onSelectCity
      onSelectedCDAcc(selectedData); // Change this line
    }
    onClose();
  };

  const filteredCDdata = cdAccData.filter((row: any) => {
    return row.CD_Account?.toString()
      .toLowerCase()
      .includes(searchValue.toLowerCase());
  });

  const WrapTextCell: React.FC<WrapTextCellProps> = ({ value }) => {
    return <div style={{ whiteSpace: "pre-wrap" }}>{value}</div>;
  };

  return (
    <ThemeProvider theme={theme}>
      <Modal open={isOpen} onClose={onClose}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "60%",
            maxWidth: "800px",
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 4,
          }}
        >
          <Typography
            variant="h6"
            sx={{
              backgroundColor: "#f0f0f0",
              padding: "16px",
              color: `${theme.palette.primary.main}`,
              fontWeight: "bold",
              marginBottom: "16px",
            }}
          >
            Address Selection
          </Typography>
          <SearchInput
            value={searchValue}
            onChange={setSearchValue}
            placeholder="Search CD Account"
          />
          <DataGrid
            columns={columns}
            rows={filteredCDdata}
            autoHeight
            getRowId={(row) => row.Id}
            checkboxSelection
            onRowSelectionModelChange={handleRowSelection}
          />
          <Button onClick={onClose} sx={{ marginTop: 2 }}>
            Close
          </Button>
        </Box>
      </Modal>
    </ThemeProvider>
  );
};

export default CDAccDataModal;

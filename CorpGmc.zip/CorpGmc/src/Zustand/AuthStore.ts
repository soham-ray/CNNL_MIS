import { create } from "zustand";
import { persist } from "zustand/middleware";

type AuthStore = {
  isAuthenticated: boolean;
  authenticate: () => void;
  signout: () => void;
};

export const useAuthStore = create(
  persist<AuthStore>(
    (set) => ({
      isAuthenticated: false,
      authenticate: () => set({ isAuthenticated: true }),
      signout: () => set({ isAuthenticated: false }),
    }),
    {
      name: "auth-storage", // unique name of the storage
      getStorage: () => localStorage, // specify the storage to use (localStorage)
    }
  )
);

import React from "react";
import AxiosInstance from "./API/axios";
import { Button } from "@mui/material";
import { useTokenStore } from "./Zustand/TokenStore";
import Layout from "Components/Layout";
import Header from "Components/Header";
import bg from "./assets/30.1.png";

const Home = () => {
  return (
    <Layout>
      <div
        className="flex justify-center items-center h-screen bg-cover bg-center"
        style={{
          backgroundImage: `url(${bg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="text-center">
          <h1 className="text-6xl text-primary font-bold mb-4">
            Welcome to our portal!
          </h1>
          <p className="text-lg text-slate-600">
            Explore and enjoy our content.
          </p>
        </div>
      </div>
    </Layout>
  );
};

export default Home;

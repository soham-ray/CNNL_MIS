import {
  Box,
  Button,
  CircularProgress,
  FormControl,
  FormHelperText,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
  ThemeProvider,
} from "@mui/material";
import { BASE_API_URL } from "API/Base";
import Header from "Components/Header";
import Layout from "Components/Layout";
import AddressDataModal from "Modals/AddressDataModal";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";
import CDAccDataModal from "Modals/CDAccDataModal";
import CPDataModal from "Modals/CPDataModal";
import theme from "theme";
import { ProductDetails, CRUDFormPageProps } from "types";
import AxiosInstance from "API/axios";

const CRUDForm: React.FC<CRUDFormPageProps> = ({ mode, data, fields }) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [productdata, setProductData] = useState<any>([]);
  const [isAddressModalOpen, setIsAddressModalOpen] = useState<boolean>(false);
  const [isCPModalOpen, setIsCPModalOpen] = useState<boolean>(false);
  const [isCDAccModalOpen, setIsCDAccModalOpen] = useState<boolean>(false);
  const [selectedAddress, setSelectedAddress] = useState<any>(null);
  const [selectedCP, setSelectedCP] = useState<any>(null);
  const [selectedCDAcc, setSelectedCDAcc] = useState<any>(null);
  const [selectedStatus, setSelectedStatus] = useState<any>(null);
  const [editedValues, setEditedValues] = useState<any>({});
  const [formData, setFormData] = useState({
    Customer_Name: "",
    Address_1: "",
    CP_Id: "",
    Product_Id: "", // Corrected field name
    CD_Id: "",
    IsStatus: "active",
  });
  const [errors, setErrors] = useState({
    Customer_Name: "",
    Address_1: "",
    CP_Id: "",
    Product_Id: "",
    CD_Id: "",
    IsStatus: "",
  });
  const [selectedProductName, setSelectedProductName] = useState<string>("");
  const [productNameIdMap, setProductNameIdMap] = useState<any>({});
  const navigate = useNavigate();

  console.log(fields);

  const handleAddressModalOpen = () => {
    setIsAddressModalOpen(true);
  };

  const handleAddressModalClose = () => {
    setIsAddressModalOpen(false);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await AxiosInstance.get(
          `${BASE_API_URL}/admin/v1/product-details`
        );
        const data: ProductDetails[] = response.data;
        setProductData(data);

        // Create a mapping between product names and IDs
        const nameIdMap: Record<string, number> = {};
        data.forEach((product: ProductDetails) => {
          nameIdMap[product.Product_Name] = product.Id;
        });
        setProductNameIdMap(nameIdMap);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [mode]);

  useEffect(() => {
    // If in edit mode and data is available, set the form data
    if (mode === "edit" && data) {
      setEditedValues(data);

      // Initialize form data with existing data
      setFormData({
        Customer_Name: data.Customer_Name || "",
        Address_1: data.Address_1 || "",
        CP_Id: data.CP_Id || "",
        Product_Id: data.Product_Id || "",
        CD_Id: data.CD_Id || "",
        IsStatus: data.IsStatus || "",
      });

      // Pre-select the corresponding values from the data
      setSelectedCP({ CP_Name: data.CP_Name });
      setSelectedCDAcc({ CD_Account: data.CD_Account });
      setSelectedProductName(data.Product_Name || "");
      setSelectedStatus(data.IsStatus);
    }
  }, [mode, data]);

  // Callback function when an address is selected in the modal
  const handleSelectedAddress = (selectedAddress: any) => {
    setIsAddressModalOpen(false); // Close the modal
    setSelectedAddress(selectedAddress); // Set the selected address
    console.log(selectedAddress);
    handleInputChange("Address_1", selectedAddress.Address_1); // Update the form and edited values
  };

  const handleInputChange = (field: string, value: string | any) => {
    if (typeof value === "object" && value !== null) {
      // Handle the case when a value is selected from the modal
      setFormData((prevData) => ({
        ...prevData,
        [field]: value.Id, // Assuming the selected value has an 'Id' property
      }));

      // Update the product name separately
      if (field === "Product_Id") {
        setSelectedProductName(value); // Update the selected product name
        console.log(value);
      }

      if (field === "IsStatus") {
        setSelectedStatus(value);
        console.log(value);
      }
      // Update the edited values
      setEditedValues((prevValues: any) => ({
        ...prevValues,
        [field]: value, // Assuming the selected value has the same field name
      }));
    } else {
      // Update the product name and status separately
      if (field === "Product_Id") {
        setSelectedProductName(value); // Update the selected product name
        console.log(value);
      }

      if (field === "IsStatus") {
        setSelectedStatus(value);
        console.log(value);
      }

      // Handle the case when the value is directly entered in the input field
      setFormData((prevData) => ({
        ...prevData,
        [field]: value,
      }));
    }
  };

  const validateForm = () => {
    let isValid = true;
    const newErrors = {
      Customer_Name: "",
      Address_1: "",
      CP_Id: "",
      Product_Id: "",
      CD_Id: "",
      IsStatus: "",
    };

    // Validate Customer_Name
    if (!formData.Customer_Name.trim()) {
      newErrors.Customer_Name = "Customer Name is required";
      isValid = false;
    } else if (!/^[A-Za-z\s]+$/.test(formData.Customer_Name.trim())) {
      newErrors.Customer_Name = "Invalid characters in Customer Name";
      isValid = false;
    }

    // Validate Address_1
    if (!formData.Address_1.trim()) {
      newErrors.Address_1 = "Address is required";
      isValid = false;
    } else if (formData.Address_1.trim().length < 5) {
      newErrors.Address_1 = "Address should be at least 5 characters long";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = async () => {
    try {
      setLoading(true);

      if (!validateForm()) {
        return;
      }
      if (mode === "create") {
        // Convert status to boolean
        const isStatusActive = formData.IsStatus === "active";

        // Create new data object with the form data
        const newData = {
          Customer_Name: formData.Customer_Name,
          Address_Id: selectedAddress?.Id,
          CP_Id: selectedCP?.Id,
          Product_Id: productNameIdMap[selectedProductName] || "",
          CD_Id: selectedCDAcc?.Id,
          IsStatus: isStatusActive,
        };

        console.log("data to be submitted", newData);
        // Send POST request to add a new customer
        const response = await AxiosInstance.post(
          `${BASE_API_URL}/admin/v1/add-customer`,
          newData
        );

        // Show success or error toast based on the response
        if (response.data) {
          toast.success("Customer added successfully");
        } else {
          toast.error("Something went wrong");
        }
      } else if (mode === "edit") {
        // Convert status to boolean
        const isStatusActive = formData.IsStatus === "active";
        const newData = {
          Customer_Name: formData.Customer_Name,
          Address_Id: selectedAddress?.Id ?? data.Address_Id ?? null,
          CP_Id: selectedCP?.Id ?? formData.CP_Id ?? null,
          Product_Id: productNameIdMap[selectedProductName] || "",
          CD_Id: selectedCDAcc?.Id || formData.CD_Id || null,
          IsStatus: selectedStatus || formData.IsStatus || isStatusActive,
        };

        console.log("data to be submitted", newData);
        // Send PUT request to update customer details
        const response = await AxiosInstance.put(
          `${BASE_API_URL}/admin/v1/customer-details/${data.Id}`,
          newData
        );

        // Show success toast if the customer was updated successfully
        if (response.data) {
          toast.success("Customer updated successfully");
        }
      }
    } catch (error: any) {
      if (error.response) {
        if (error.response.status === 400) {
          toast.error(error.response.data.detail || "Bad Request");
        } else {
          // Handle other error status codes
          toast.error(`Server Error: ${error.response.status}`);
        }
      } else if (error.request) {
        toast.error("No response received from the server");
      } else {
        toast.error("Error setting up the request");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    navigate("/customer-master");
  };

  return (
    <Layout>
      <ThemeProvider theme={theme}>
        <AddressDataModal
          isOpen={isAddressModalOpen}
          onClose={handleAddressModalClose}
          onSelectedAddress={handleSelectedAddress}
        />
        <CPDataModal
          isOpen={isCPModalOpen}
          onClose={() => setIsCPModalOpen(false)}
          onSelectedCP={(selectedCP: any) => setSelectedCP(selectedCP)}
        />
        <CDAccDataModal
          isOpen={isCDAccModalOpen}
          onClose={() => setIsCDAccModalOpen(false)}
          onSelectedCDAcc={(selectedCDAcc: any) =>
            setSelectedCDAcc(selectedCDAcc)
          }
        />

        {loading && (
          <Box
            sx={{
              position: "fixed",
              top: 0,
              left: 0,
              width: "100%",
              height: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",

              zIndex: 1000,
            }}
          >
            <CircularProgress size={50} />
          </Box>
        )}

        <Box sx={{ width: "80%", margin: "50px auto" }}>
          <Header
            title={
              mode === "view"
                ? "View Customer Details"
                : mode === "edit"
                ? "Edit Customer Details"
                : mode === "create"
                ? "Create new customer "
                : ""
            }
            subtitle={""}
          />

          <Grid container spacing={2}>
            {mode === "create" && (
              <>
                <Grid item xs={6}>
                  <TextField
                    label="Customer Name"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    required
                    value={formData.Customer_Name}
                    onChange={(e) =>
                      handleInputChange("Customer_Name", e.target.value)
                    }
                    sx={{ marginBottom: "16px" }}
                    error={!!errors.Customer_Name}
                    helperText={errors.Customer_Name}
                  />
                </Grid>
                <Grid item xs={6}>
                  <TextField
                    label="Address"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    required
                    value={selectedAddress?.Address_1 || ""}
                    onClick={handleAddressModalOpen}
                    onChange={(e) =>
                      handleInputChange("Address_1", e.target.value)
                    }
                    error={!!errors.Address_1}
                    helperText={errors.Address_1}
                  />
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    label="Contact Person"
                    variant="outlined"
                    fullWidth
                    required
                    margin="normal"
                    value={selectedCP?.CP_Name || ""}
                    onClick={() => setIsCPModalOpen(true)}
                    onChange={(e) => {
                      handleInputChange("CP_Id", e.target.value); // Clear the previous CP_Id when changing the name
                    }}
                    error={!!errors.CP_Id}
                    helperText={errors.CP_Id}
                  />
                </Grid>

                <Grid item xs={6}>
                  <FormControl fullWidth margin="normal" variant="outlined">
                    <InputLabel>Product Name</InputLabel>
                    <Select
                      label="Product Name"
                      value={selectedProductName || ""}
                      error={!!errors.Product_Id}
                      required
                      onChange={(e) =>
                        handleInputChange(
                          "Product_Id",
                          e.target.value as string
                        )
                      }
                    >
                      {productdata.map((product: ProductDetails) => (
                        <MenuItem value={product.Product_Name} key={product.Id}>
                          {product.Product_Name}
                        </MenuItem>
                      ))}
                    </Select>
                    <FormHelperText>{errors.Product_Id}</FormHelperText>
                  </FormControl>
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    label="CD Account"
                    variant="outlined"
                    required
                    fullWidth
                    margin="normal"
                    value={selectedCDAcc?.CD_Account || ""}
                    onClick={() => setIsCDAccModalOpen(true)}
                    onChange={(e) =>
                      handleInputChange("CD_Account", e.target.value)
                    }
                    error={!!errors.CD_Id}
                    helperText={errors.CD_Id}
                  />
                </Grid>
                <Grid item xs={6}>
                  <FormControl fullWidth margin="normal" variant="outlined">
                    <InputLabel>Status</InputLabel>
                    <Select
                      label="Status"
                      required
                      value={selectedStatus || ""}
                      onChange={(e) =>
                        handleInputChange("IsStatus", e.target.value as string)
                      }
                      error={!!errors.IsStatus}
                    >
                      <MenuItem value={"true"}>Active</MenuItem>
                      <MenuItem value={"false"}>Inactive</MenuItem>
                    </Select>
                    <FormHelperText>{errors.IsStatus}</FormHelperText>
                  </FormControl>
                </Grid>
              </>
            )}
            {mode === "edit" && (
              <>
                <Grid item xs={6}>
                  <TextField
                    label="Customer_Name"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    required
                    value={formData?.Customer_Name || ""}
                    onChange={(e) =>
                      handleInputChange("Customer_Name", e.target.value)
                    }
                    sx={{ marginBottom: "16px" }}
                    error={!!errors.Customer_Name}
                    helperText={errors.Customer_Name}
                  />
                </Grid>
                {/* Add other fields for editing in a similar manner */}
                <Grid item xs={6}>
                  <TextField
                    label="Address"
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    required
                    value={
                      selectedAddress?.Address_1 || formData?.Address_1 || ""
                    }
                    onClick={handleAddressModalOpen}
                    onChange={(e) =>
                      handleInputChange("Address_1", e.target.value)
                    }
                    error={!!errors.Address_1}
                    helperText={errors.Address_1}
                  />
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    label="Contact Person"
                    variant="outlined"
                    required
                    fullWidth
                    margin="normal"
                    value={selectedCP?.CP_Name || ""}
                    onClick={() => setIsCPModalOpen(true)}
                    onChange={(e) => {
                      handleInputChange("CP_Id", e.target.value);
                    }}
                  />
                </Grid>

                <Grid item xs={6}>
                  <FormControl fullWidth margin="normal" variant="outlined">
                    <InputLabel>Product Name</InputLabel>
                    <Select
                      label="Product Name"
                      required
                      value={selectedProductName || ""}
                      onChange={(e) =>
                        handleInputChange(
                          "Product_Id",
                          e.target.value as string
                        )
                      }
                    >
                      {productdata.map((product: ProductDetails) => (
                        <MenuItem value={product.Product_Name} key={product.Id}>
                          {product.Product_Name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>

                <Grid item xs={6}>
                  <TextField
                    label="CD Account"
                    required
                    variant="outlined"
                    fullWidth
                    margin="normal"
                    value={selectedCDAcc?.CD_Account || ""}
                    onClick={() => setIsCDAccModalOpen(true)}
                    onChange={(e) => handleInputChange("CD_Id", e.target.value)}
                  />
                </Grid>
                <Grid item xs={6}>
                  <FormControl fullWidth margin="normal" variant="outlined">
                    <InputLabel>Status</InputLabel>
                    <Select
                      label="Status"
                      value={formData.IsStatus ? "true" : "false"}
                      required
                      onChange={(e) =>
                        handleInputChange(
                          "IsStatus",
                          e.target.value === "true" ? 1 : 0
                        )
                      }
                    >
                      <MenuItem value={"true"}>Active</MenuItem>
                      <MenuItem value={"false"}>Inactive</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
              </>
            )}

            {mode === "view" && (
              <>
                <Grid container spacing={2}>
                  {fields.map(({ label, key, type }) => (
                    <Grid item xs={6} key={key}>
                      <TextField
                        key={key}
                        label={label}
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        value={data[key] || ""}
                      />
                    </Grid>
                  ))}
                </Grid>
              </>
            )}
          </Grid>

          <Box mt={2} display="flex" justifyContent="space-between">
            {mode === "edit" && (
              <Button
                variant="contained"
                color="primary"
                onClick={handleSubmit}
                sx={{
                  color: "#fff",
                }}
              >
                Save Changes
              </Button>
            )}

            {mode === "create" && (
              <Button
                variant="contained"
                color="primary"
                sx={{
                  color: "#fff",
                }}
                onClick={handleSubmit}
              >
                Create
              </Button>
            )}
            <Button
              variant="outlined"
              onClick={handleBack}
              sx={{ border: `1px solid ${theme.palette.primary.main}` }}
            >
              Back
            </Button>
          </Box>
        </Box>
      </ThemeProvider>
      <Toaster />
    </Layout>
  );
};

export default CRUDForm;

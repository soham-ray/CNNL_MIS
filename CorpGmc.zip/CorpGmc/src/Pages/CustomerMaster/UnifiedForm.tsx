import { BASE_API_URL } from "API/Base";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router";
import { UnifiedFormParams } from "types";
import CRUDForm from "./CRUDForm";
import axios from "axios";

const UnifiedForm: React.FC = () => {
  const { mode, id } = useParams<UnifiedFormParams>();
  const [apiData, setApiData] = useState<any>([]);
  const base64Decode = (encodedStr: string) => {
    return atob(encodedStr);
  };

  const decodedId = id ? base64Decode(id) : null;
  console.log(decodedId);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${BASE_API_URL}/admin/v1/customer-details/${decodedId}`
        );
        const data = response.data;

        const filteredData = decodedId
          ? data.filter((item: any) => item.Id === Number(decodedId))
          : data;
        setApiData(filteredData);
        console.log(filteredData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    if (mode !== "create") {
      fetchData();
    }
  }, [mode, decodedId]);

  const createFields =
    mode === "create" // Check if the mode is "create"
      ? [
          { label: "City", key: "City_Id", type: "modal" }, // If it is, set an array of create fields
          { label: "Address", key: "Address_1" },
        ]
      : apiData.length > 0 // Check if apiData has data
      ? Object.keys(apiData[0]) // Get the keys of the first item in apiData
          .filter(
            (key) =>
              ![
                "Id",
                "Product_Id",
                "Address_Id",
                "CP_Id",
                "CD_Id",
                "IsStatus",
                "Created_By",
                "Created_On",
                "Modify_By",
                "Modify_On",
              ].includes(key) // Exclude specific keys from the list
          )
          .map((key) => ({ label: key, key })) // Map the keys to an array of objects with label and key properties
      : []; // If apiData is empty, set an empty array


  return (
    <div>
      {mode && ( // Check if mode exists
        <>
          {" "}
          {/* React fragment */}
          <CRUDForm
            mode={mode}
            data={apiData.find((item: any) => item.Id === Number(decodedId))}
            fields={createFields}
          />
        </>
      )}
    </div>
  );
};

export default UnifiedForm;

import React, { useState } from "react";
import {
  Modal,
  Typography,
  Box,
  TextField,
  Button,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
} from "@mui/material";
import { SelectChangeEvent } from "@mui/material";
import axios from "axios";
import toast, { Toaster } from "react-hot-toast";
import { BASE_API_URL } from "../../../API/Base";

interface AddAddressModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddressAdded: (newAddress: AddressOption) => void;
  data: AddressOption[];
  cities: CityOption[];
}

interface AddAddressModal {
  newAddress: string;
  selectedCity: string;
}

interface AddressOption {
  Id: number;
  Address_1: string;
  City_Id: number;
}

interface CityOption {
  Id: number;
  State_Id: number;
  Name: string;
}

const AddAddressModal: React.FC<AddAddressModalProps> = ({
  isOpen,
  onClose,
  onAddressAdded,
  data,
  cities,
}) => {
  const [state, setState] = useState<AddAddressModal>({
    newAddress: "",
    selectedCity: "", // Initialize as an empty string
  });

  const handleAddAddress = async () => {
    try {
      const completeData = {
        Address_1: state.newAddress,
        City_Id: state.selectedCity,
        Created_By: 1,
        Created_On: "2024-01-03 07:25:50",
        Modify_By: 1,
        Modify_On: "2024-01-03 07:25:50",
      };
      const url = `${BASE_API_URL}/admin/v1/address-details`;
      const response = await axios.post(url, completeData);

      if (response.status === 200) {
        const newAddress = response.data;
        onAddressAdded(newAddress);
        toast.success("Address added successfully");
        onClose();
      }
    } catch (error) {
      console.error("Error adding address:", error);
    }
  };

  const handleAddressChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    setState((prevState) => ({
      ...prevState,
      newAddress: event.target.value,
    }));
  };

  const handleCityChange = (event: SelectChangeEvent<string>) => {
    const selectedValue = event.target.value;
    const selectedCity = cities.find((city) => city.Name === selectedValue);

    setState((prevState) => ({
      ...prevState,
      selectedCity: selectedCity ? selectedCity.Id.toString() : "",
    }));
    console.log(selectedCity);
  };

  return (
    <div>
      <Modal open={isOpen} onClose={onClose}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: "400px",
            bgcolor: "background.paper",
            boxShadow: 24,
            p: 4,
          }}
        >
          <Typography variant="h6" id="modal-title" sx={{ mb: 2 }}>
            Add new address
          </Typography>
          <FormControl fullWidth sx={{ mb: 2 }}>
            <InputLabel>Select City</InputLabel>
            <Select
              label="Select City"
              value={state.selectedCity}
              variant="outlined"
              onChange={handleCityChange}
            >
              <MenuItem value="">Select City</MenuItem>
              {cities.map((city) => (
                <MenuItem key={city.Id} value={city.Name}>
                  {city.Name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField
            label="Address"
            variant="outlined"
            fullWidth
            value={state.newAddress}
            onChange={handleAddressChange}
            sx={{ mb: 2 }}
          />
          <Button
            variant="contained"
            color="primary"
            onClick={handleAddAddress}
          >
            Add Address
          </Button>
        </Box>
      </Modal>
      <Toaster />
    </div>
  );
};

export default AddAddressModal;

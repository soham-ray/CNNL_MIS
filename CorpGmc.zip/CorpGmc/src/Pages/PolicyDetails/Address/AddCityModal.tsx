// AddNewCityModal.tsx
import React, { useState } from "react";
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  Button,
  FormControl,
  FormLabel,
  Input,
  Select,
  ModalFooter,
  FormErrorMessage,
} from "@chakra-ui/react";
import { useForm, SubmitHandler } from "react-hook-form";
import axios from "axios";
import { BASE_API_URL } from "../../../API/Base";

interface AddNewCityModalProps {
  isOpen: boolean;
  onClose: () => void;
  stateIds: number[];
  onCityAdded: (cityName: string, stateId: number) => void;
}

interface FormData {
  city: string;
  state_id: number;
}

const AddNewCityModal: React.FC<AddNewCityModalProps> = ({
  isOpen,
  onClose,
  stateIds,
  onCityAdded,
}) => {
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<FormData>();

  const [selectedStateId, setSelectedStateId] = useState<number | null>(null);

  const onSubmit: SubmitHandler<FormData> = async (data) => {
    try {
      const completeData = {
        Name: data.city,
        State_Id: data.state_id,
        Created_By: 1,
        Created_On: "2024-01-03 07:25:50",
        Modify_By: 1,
        Modify_On: "2024-01-03 07:25:50",
      };

      const url = `${BASE_API_URL}/admin/v1/city`;
      const response = await axios.post(url, completeData);

      if (response.status === 200) {
        // City added successfully, update the state in the parent component
        onCityAdded(data.city, data.state_id);
        setSelectedStateId(data.state_id);
        // Clear the city input value
        setValue("city", "");
        console.log("City added successfully");
      } else {
        console.error(`Error adding city - Status: ${response.status}`);
      }
    } catch (error) {
      console.error("Error adding city:", error);
    } finally {
      onClose();
    }
  };
  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Add new city</ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <form onSubmit={handleSubmit(onSubmit)}>
            <FormControl>
              <Input
                type="text"
                placeholder="Enter city name"
                {...register("city", { required: "State is required" })}
                required
                onChange={(e) => {
                  // Set the selected address in the form data
                  setValue("city", e.target.value);
                }}
              />
              <FormErrorMessage>
                {errors.city && errors.city.message}
              </FormErrorMessage>
            </FormControl>

            <FormControl mt={4} isInvalid={!!errors.state_id}>
              <Select
                placeholder="Select your State"
                {...register("state_id", { required: "State is required" })}
                value={selectedStateId || ""}
                onChange={(e) => setSelectedStateId(Number(e.target.value))}
              >
                {stateIds.map((stateId) => (
                  <option key={`state-${stateId}`} value={stateId}>
                    State {stateId}
                  </option>
                ))}
              </Select>
              <FormErrorMessage>
                {errors.state_id && errors.state_id.message}
              </FormErrorMessage>
            </FormControl>
            <ModalFooter>
              <Button colorScheme="teal" mr={3} type="submit">
                Submit
              </Button>
              <Button onClick={onClose}>Cancel</Button>
            </ModalFooter>
          </form>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
};

export default AddNewCityModal;

import React, { useEffect, useState } from "react";
import { useForm, SubmitHandler } from "react-hook-form";
import { BASE_API_URL } from "../../API/Base";
import axios from "axios";

type PolicyFormInputs = {
  clientName: string;
  address: string;
  city: string;
  pincode: string;
  contactPerson: string;
};

type AddressOption = {
  address_id: number;
  city: string;
  pincode: string;
  address: string;
  created_by: number;
  created_on: string;
  modified_by: number;
  modified_on: string;
};

const PolicyForm: React.FC = () => {
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<PolicyFormInputs>();
  const [addressOptions, setAddressOptions] = useState<AddressOption[]>([]);
  const [showInput, setShowInput] = useState(false);

  useEffect(() => {
    const fetchAddressOptions = async () => {
      try {
        const response = await axios(`${BASE_API_URL}/admin/address-details`);
        setAddressOptions(response.data);
        console.log(response.data);
      } catch (error) {
        console.error("Error fetching addresses:", error);
      }
    };

    fetchAddressOptions();
  }, []);

  const handleAddressSelect = (selectedAddress: string) => {
    setValue("address", selectedAddress);
    setShowInput(false);
  };

  const toggleInput = () => {
    setValue("address", ""); // Reset address when switching to input
    setShowInput(!showInput);
  };

  const onSubmit: SubmitHandler<PolicyFormInputs> = (data) => {
    console.log(data);
  };

  return (
    <form
      onSubmit={handleSubmit(onSubmit)}
      className="max-w-md p-6 mx-auto mt-8 bg-white rounded-md shadow-md"
    >
      <div className="mb-4">
        <label
          htmlFor="clientName"
          className="block text-sm font-medium text-gray-600"
        >
          Client Name:
        </label>
        <input
          {...register("clientName", { required: "Client name is required" })}
          className="w-full p-2 mt-1 border rounded-md"
        />
        {errors.clientName && (
          <span className="text-xs text-red-500">
            {errors.clientName.message}
          </span>
        )}
      </div>

      <div className="mb-4">
        <label
          htmlFor="address"
          className="block text-sm font-medium text-gray-600"
        >
          Address:
        </label>
        {showInput ? (
          <input
            {...register("address", { required: "Address is required" })}
            className="w-full p-2 mt-1 border rounded-md"
          />
        ) : (
          <div className="flex">
            <select
              {...register("address")}
              onChange={(e) => handleAddressSelect(e.target.value)}
              className="p-2 mr-2 border rounded-md"
            >
              <option value="">Select an address</option>
              {addressOptions.map((addressObj, index) => (
                <option key={index} value={addressObj.address}>
                  {addressObj.address}
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={toggleInput}
              className="p-2 bg-gray-200 border rounded-md"
            >
              Add New
            </button>
          </div>
        )}
        {errors.address && (
          <span className="text-xs text-red-500">{errors.address.message}</span>
        )}
      </div>

      <div className="mb-4">
        <label
          htmlFor="city"
          className="block text-sm font-medium text-gray-600"
        >
          City:
        </label>
        <input
          {...register("city", { required: "City is required" })}
          className="w-full p-2 mt-1 border rounded-md"
        />
        {errors.city && (
          <span className="text-xs text-red-500">{errors.city.message}</span>
        )}
      </div>

      <div className="mb-4">
        <label
          htmlFor="contactPerson"
          className="block text-sm font-medium text-gray-600"
        >
          Contact Person:
        </label>
        <input
          {...register("contactPerson", {
            required: "Contact person is required",
          })}
          className="w-full p-2 mt-1 border rounded-md"
        />
        {errors.contactPerson && (
          <span className="text-xs text-red-500">
            {errors.contactPerson.message}
          </span>
        )}
      </div>

      <button
        type="submit"
        className="px-4 py-2 text-white rounded-md bg-blue hover:bg-blue-600 focus:outline-none focus:ring focus:border-blue-300"
      >
        Submit
      </button>
    </form>
  );
};

export default PolicyForm;

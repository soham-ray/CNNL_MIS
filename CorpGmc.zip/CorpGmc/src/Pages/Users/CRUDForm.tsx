import React, { ChangeEvent, useEffect, useState } from "react";
import theme from "theme";
import {
  Autocomplete,
  Button,
  Chip,
  FormControl,
  FormHelperText,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import { Box } from "@mui/system";
import { BASE_API_URL } from "API/Base";
import AxiosInstance from "API/axios";
import Header from "Components/Header";
import Layout from "Components/Layout";
import toast from "react-hot-toast";
import { useNavigate } from "react-router";
import { CRUDFormPageProps, Role } from "types";
import CustomerDataModal from "Modals/CustomerDataModal";
import { CircularProgress } from "@mui/material";

import axios from "axios";
import { Business } from "@mui/icons-material";

const CRUDForm: React.FC<CRUDFormPageProps> = ({ mode, data, fields }) => {
  const [roles, setRoles] = useState<any>([]);
  const [customers, setCustomers] = useState<any>([]);
  const [userStatus, setUserStatus] = useState<any>(null);
  const [isCustomerModalOpen, setIsCustomerModalOpen] =
    useState<boolean>(false);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [selectedStatus, setSelectedStatus] = useState<any>(null);
  const [editedValues, setEditedValues] = useState<any>({});
  const [loading, setLoading] = useState<boolean>(false);
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [formData, setFormData] = useState({
    Id: "",
    User_Name: "",
    Email_Id: "",
    Mobile_No: "",
    IsStatus: "active",
    Business_Id: 1,
    Password: "",
    User_Type: "",
    Role_Id: [] as number[], // Change the type to string[]
    Customer_Id: "",
  });

  const [errors, setErrors] = useState({
    User_Name: "",
    Email_Id: "",
    Mobile_No: "",
    IsStatus: "",

    Password: "",
    User_Type: "",
    Role_Id: "",
    Customer_Id: "",
  });
  const navigate = useNavigate();

  useEffect(() => {
    if (mode === "edit" && data) {
      setEditedValues(data);

      setFormData({
        Id: data.Id.toString(),
        User_Name: data.User_Name,
        Email_Id: data.Email_Id,
        Mobile_No: data.Mobile_No,
        IsStatus: data.IsStatus.toString(),
        Business_Id: data.Business_Id.toString() || "1",
        Password: data.Password,
        User_Type: data.User_Type_Name,
        Role_Id: data.Role_Id || [],
        Customer_Id: data.Customer_Id,
      });

      setSelectedRoles(data.Role_Names || []);
      setSelectedCustomer(data.Customer_Name);
      setSelectedStatus(data.IsStatus);
    }
    fetchData();
    fetchCustomerData();
    fetchStatusType();
  }, [mode, data]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const response = await AxiosInstance.get(
        `${BASE_API_URL}/admin/roles/v1/get-all-roles`
      );
      const data: Role[] = response.data;
      setRoles(data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
    }
  };

  const fetchCustomerData = async () => {
    try {
      setLoading(true);
      const response = await AxiosInstance.get(
        `${BASE_API_URL}/admin/v1/customer-details`
      );
      const data = response.data;
      setCustomers(data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
    }
  };

  const fetchStatusType = async () => {
    try {
      setLoading(true);
      const response = await axios.get(
        `${BASE_API_URL}/admin/users/v1/status-type`
      );
      const data = response.data;
      setUserStatus(data);

      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
    }
  };

  // const handleInputChange = (field: string, value: string | any) => {
  //   if (typeof value === "object" && value !== null) {
  //     // Handle the case when a value is selected from the modal
  //     setFormData((prevData) => ({
  //       ...prevData,
  //       [field]: value.Id, // Assuming the selected value has an 'Id' property
  //     }));

  //     if (field === "Role_Id") {
  //       setSelectedRoles(value);
  //       console.log(value);
  //     } else if (field === "User_Type") {
  //       setFormData((prevData) => ({
  //         ...prevData,
  //         [field]: value.Status_Name,
  //       }));

  //       // Update the edited values
  //       setEditedValues((prevValues: any) => ({
  //         ...prevValues,
  //         [field]: value.Status_Name, // Set to the selected 'Status_Name'
  //       }));
  //     } else {
  //       // Update the edited values for other fields
  //       setEditedValues((prevValues: any) => ({
  //         ...prevValues,
  //         [field]: value, // Assuming the selected value has the same field name
  //       }));
  //     }
  //   } else {
  //     if (field === "Role_Id") {
  //       setSelectedRoles(value);
  //     }else if (field === "User_Type") {
  //       setFormData((prevData) => ({
  //         ...prevData,
  //         [field]: value,
  //       }));

  //       // // Update the edited values directly with the string value
  //       // setEditedValues((prevValues: any) => ({
  //       //   ...prevValues,
  //       //   [field]: value,
  //       // }));
  //     } else {
  //       // Update the edited values for other fields
  //       setFormData((prevData) => ({
  //         ...prevData,
  //         [field]: field === "IsStatus" ? (value === "true" ? 1 : 0) : value,
  //       }));
  //       setEditedValues((prevValues: any) => ({
  //         ...prevValues,
  //         [field]: field === "IsStatus" ? (value === "true" ? 1 : 0) : value,
  //       }));
  //     }
  //   }
  // };

  const handleInputChange = (field: string, value: string | any) => {
    const updateState = (field: string, value: any) => {
      setFormData((prevData) => ({
        ...prevData,
        [field]: value,
      }));
      setEditedValues((prevValues: any) => ({
        ...prevValues,
        [field]: value,
      }));
    };

    if (typeof value === "object" && value !== null) {
      // Handle the case when a value is selected from the modal
      updateState(field, value.Id);

      if (field === "Role_Id") {
        setSelectedRoles(value);
      } else if (field === "User_Type") {
        updateState(field, value.Status_Name);
      } else if (field === "IsStatus") {
        updateState(field, value === "true" ? 1 : 0);
      }
    } else {
      if (field === "Role_Id") {
        setSelectedRoles(value);
      } else if (field === "IsStatus") {
        updateState(field, value === "true" ? 1 : 0);
      } else {
        updateState(field, value);
      }
    }
  };

  const validateForm = () => {
    let isValid = true;
    const newErrors = {
      User_Name: "",
      Email_Id: "",
      Mobile_No: "",
      Password: "",
      User_Type: "",
      Role_Id: "",
      Customer_Id: "",
      IsStatus: "",
    };

    // Validate User_Name
    if (!formData.User_Name) {
      newErrors.User_Name = "Username is required";
      isValid = false;
    } else if (formData.User_Name.length < 5) {
      newErrors.User_Name = "Invalid Username";
      isValid = false;
    }

    // Validate Email_Id
    if (!formData.Email_Id) {
      newErrors.Email_Id = "Email Id is required";
      isValid = false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.Email_Id)) {
      newErrors.Email_Id = "Invalid Email Id";
      isValid = false;
    }

    // Validate Mobile_No
    if (!formData.Mobile_No) {
      newErrors.Mobile_No = "Mobile No is required";
      isValid = false;
    } else if (!/^\d{10}$/.test(formData.Mobile_No)) {
      newErrors.Mobile_No = "Invalid Mobile No";
      isValid = false;
    }

    // Validate Password
    if (!formData.Password) {
      newErrors.Password = "Password is required";
      isValid = false;
    } else if (formData.Password.length < 8) {
      newErrors.Password = "Password should be at least 8 characters long";
      isValid = false;
    }

    // Validate User_Type
    if (!formData.User_Type) {
      newErrors.User_Type = "User Type is required";
      isValid = false;
    } else if (
      !userStatus.find(
        (status: any) => status.Status_Name === formData.User_Type
      )
    ) {
      newErrors.User_Type = "Invalid User Type";
      isValid = false;
    }

    // Validate Role_Id
    if (!formData.Role_Id) {
      newErrors.Role_Id = "Role Id is required";
      isValid = false;
    }

    // Validate Customer_Id
    if (!formData.Customer_Id) {
      newErrors.Customer_Id = "Customer Id is required";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleSubmit = async () => {
    try {
      if (!validateForm()) {
        return;
      }
      if (mode === "create") {
        const newData = {
          User_Name: formData.User_Name,
          Email_Id: formData.Email_Id,
          Mobile_No: formData.Mobile_No,
          Password: formData.Password,
          Business_Id: "1",
          IsStatus: formData.IsStatus ? 1 : 0,
          User_Type: userStatus.find(
            (status: any) => status.Status_Name === formData.User_Type
          )?.Id,
          Role_Id: formData.Role_Id || [],
          // Customer_Id: selectedCustomer.Id,
          Customer_Id: formData.Customer_Id,
        };

        console.log(newData);
        const response = await AxiosInstance.post(
          `${BASE_API_URL}/admin/users/v1/add-users`,
          newData
        );

        if (response.data) {
          toast.success("User created successfully");
          setFormData({
            Id: "",
            User_Name: "",
            Email_Id: "",
            Mobile_No: "",
            Password: "",
            User_Type: "",
            Role_Id: [],
            IsStatus: "true",
            Business_Id: 1,
            Customer_Id: "",
          });
        }
      } else if (mode === "edit") {
        const roleIds =
          Array.isArray(editedValues.Role_Id) &&
          editedValues.Role_Id.every((id: any) => typeof id === "number")
            ? editedValues.Role_Id
            : typeof editedValues.Role_Id === "string"
            ? JSON.parse(editedValues.Role_Id)
            : [editedValues.Role_Id]; // Wrap the original value in an array

        const newData = {
          User_Name: editedValues.User_Name as string,
          Email_Id: editedValues.Email_Id as string,
          Mobile_No: editedValues.Mobile_No as string,
          IsStatus: editedValues.IsStatus,
          User_Type: (userStatus.find(
            (status: any) => status.Status_Name === editedValues.User_Type
          )?.Id || editedValues.User_Type) as number,
          Customer_Id: editedValues.Customer_Id,
          Business_Id: 1,
          Role_Id: roleIds, // Keep Role_Id as an array
        };

        console.log(newData);

        const response = await AxiosInstance.put(
          `${BASE_API_URL}/admin/users/v1/users/${editedValues.Id}`,
          newData
        );

        if (response.data) {
          toast.success("User updated successfully");
        }
      }
    } catch (error: any) {
      if (error.response) {
        if (error.response.status === 400) {
          toast.error(error.response.data.detail || "Bad Request");
        } else {
          // Handle other error status codes
          toast.error(`Server Error: ${error.response.status}`);
        }
      } else if (error.request) {
        toast.error("No response received from the server");
      } else {
        toast.error("Error setting up the request");
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRoleChange = (
    event: React.SyntheticEvent,
    newValue: string[] | null
  ) => {
    setSelectedRoles(newValue || []);

    // Fetch corresponding role IDs for the selected role names
    const roleIds = (newValue || []).map((roleName) => {
      const role = roles.find((r: any) => r.Role_Name === roleName);
      return role ? role.Id : null; // Keep it as a number
    });

    // Remove null values and update Role_Id in editedValues
    setEditedValues((prevValues: any) => ({
      ...prevValues,
      Role_Id: roleIds.filter((id) => id !== null),
    }));

    // Update Role_Id in formData
    setFormData((prevData) => ({
      ...prevData,
      Role_Id: roleIds.filter((id) => id !== null),
    }));
  };

  const handleSelectedCustomer = (selectedCustomer: any) => {
    setIsCustomerModalOpen(false);
    setSelectedCustomer(selectedCustomer);
    console.log(selectedCustomer);
    handleInputChange("Customer_Id", selectedCustomer.Id);
  };

  return (
    <Layout>
      {loading && <CircularProgress />}
      <Box sx={{ width: "80%", margin: "50px auto" }}>
        <CustomerDataModal
          isOpen={isCustomerModalOpen}
          onClose={() => setIsCustomerModalOpen(false)}
          onSelectedCustomer={handleSelectedCustomer}
        />
        <Header
          title={
            mode === "view"
              ? "View user details"
              : mode === "edit"
              ? "Edit user details"
              : mode === "create"
              ? "Create new user "
              : ""
          }
          subtitle={""}
        />

        <Grid container spacing={2}>
          {mode === "create" && (
            <>
              <Grid item xs={6}>
                <TextField
                  label="Username"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  required
                  value={formData.User_Name}
                  sx={{ marginBottom: "16px" }}
                  onChange={(e) =>
                    handleInputChange("User_Name", e.target.value)
                  }
                  error={!!errors.User_Name}
                  helperText={errors.User_Name}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Email ID"
                  variant="outlined"
                  fullWidth
                  required
                  margin="normal"
                  value={formData.Email_Id}
                  onChange={(e) =>
                    handleInputChange("Email_Id", e.target.value)
                  }
                  sx={{ marginBottom: "16px" }}
                  error={!!errors.Email_Id}
                  helperText={errors.Email_Id}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Mobile Number"
                  variant="outlined"
                  fullWidth
                  required
                  margin="normal"
                  onChange={(e) =>
                    handleInputChange("Mobile_No", e.target.value)
                  }
                  value={formData.Mobile_No}
                  sx={{ marginBottom: "16px" }}
                  error={!!errors.Mobile_No}
                  helperText={errors.Mobile_No}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Password"
                  variant="outlined"
                  type="password"
                  fullWidth
                  required
                  margin="normal"
                  onChange={(e) =>
                    handleInputChange("Password", e.target.value)
                  }
                  value={formData.Password}
                  sx={{ marginBottom: "16px" }}
                  error={!!errors.Password}
                  helperText={errors.Password}
                />
              </Grid>
              <Grid item xs={6}>
                <FormControl fullWidth margin="normal" variant="outlined">
                  <InputLabel>Status</InputLabel>
                  <Select
                    label="Status"
                    value={formData.IsStatus ? "true" : "false"}
                    required
                    error={!!errors.IsStatus}
                    onChange={(e) =>
                      handleInputChange("IsStatus", e.target.value as string)
                    }
                  >
                    <MenuItem value={"true"}>Active</MenuItem>
                    <MenuItem value={"false"}>Inactive</MenuItem>
                  </Select>
                  <FormHelperText>{errors.IsStatus}</FormHelperText>
                </FormControl>
              </Grid>

              <Grid item xs={6}>
                <Autocomplete
                  multiple
                  id="role-select"
                  options={roles.map((role: any) => role.Role_Name)}
                  value={selectedRoles}
                  onChange={handleRoleChange}
                  isOptionEqualToValue={(option, value) => option === value}
                  renderOption={(props, option, { selected }) => (
                    <li
                      {...props}
                      style={{
                        backgroundColor: selected ? "#e0f7fa" : "white",
                      }}
                    >
                      {option}
                    </li>
                  )}
                  renderTags={(value, getTagProps) =>
                    value.map((option, index) => (
                      <Chip
                        label={option}
                        {...getTagProps({ index })}
                        sx={{ marginRight: 0.5 }}
                      />
                    ))
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Roles"
                      variant="outlined"
                      fullWidth
                      required
                      margin="normal"
                    />
                  )}
                />
              </Grid>

              <Grid item xs={6}>
                <TextField
                  label="Customer"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  value={selectedCustomer?.Customer_Name || ""}
                  onClick={() => setIsCustomerModalOpen(true)}
                  onChange={(e) =>
                    handleInputChange("Customer_Id", e.target.value)
                  }
                  error={!!errors.Customer_Id}
                  helperText={errors.Customer_Id}
                />
              </Grid>

              <Grid item xs={6}>
                <FormControl fullWidth margin="normal" variant="outlined">
                  <InputLabel>User type</InputLabel>
                  <Select
                    value={formData.User_Type || ""}
                    label="User type"
                    error={!!errors.User_Type}
                    required
                    onChange={(e) =>
                      handleInputChange("User_Type", e.target.value as string)
                    }
                  >
                    {userStatus &&
                      userStatus.map((status: any) => (
                        <MenuItem value={status.Status_Name} key={status.Id}>
                          {status.Status_Name}
                        </MenuItem>
                      ))}
                  </Select>
                  <FormHelperText>{errors.User_Type}</FormHelperText>
                </FormControl>
              </Grid>
            </>
          )}
          {mode === "view" && (
            <>
              {loading && (
                <div
                  style={{
                    position: "fixed",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    zIndex: 9999,
                  }}
                >
                  <CircularProgress />
                </div>
              )}
              <Grid container spacing={2}>
                {fields.map(({ label, key, type }) => (
                  <Grid item xs={6} key={key}>
                    {key === "Role_Names" ? (
                      <Autocomplete
                        multiple
                        id="role-select-view"
                        options={roles.map((role: any) => role.Role_Name)}
                        value={data[key]}
                        renderTags={(value, getTagProps) =>
                          value.map((option, index) => (
                            <Chip label={option} {...getTagProps({ index })} />
                          ))
                        }
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label={label}
                            variant="outlined"
                            fullWidth
                            margin="normal"
                          />
                        )}
                      />
                    ) : (
                      <TextField
                        key={key}
                        label={label}
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        value={data[key]}
                        sx={{ marginBottom: "16px" }}
                      />
                    )}
                  </Grid>
                ))}
              </Grid>
            </>
          )}

          {mode === "edit" && (
            <>
              <Grid item xs={6}>
                <TextField
                  label="User_Name"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  value={formData.User_Name || ""}
                  onChange={(e) =>
                    handleInputChange("User_Name", e.target.value)
                  }
                ></TextField>
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Email"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  value={formData.Email_Id || ""}
                  onChange={(e) =>
                    handleInputChange("Email_Id", e.target.value)
                  }
                ></TextField>
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Mobile No"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  value={formData.Mobile_No || ""}
                  onChange={(e) =>
                    handleInputChange("Mobile_No", e.target.value)
                  }
                ></TextField>
              </Grid>
              <Grid item xs={6}>
                <FormControl fullWidth margin="normal" variant="outlined">
                  <InputLabel>Status</InputLabel>
                  <Select
                    label="Status"
                    value={formData.IsStatus ? "true" : "false"}
                    onChange={(e) =>
                      handleInputChange("IsStatus", e.target.value as string)
                    }
                  >
                    <MenuItem value={"true"}>Active</MenuItem>
                    <MenuItem value={"false"}>Inactive</MenuItem>
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={6}>
                <Autocomplete
                  multiple
                  id="role-select"
                  options={roles.map((role: any) => role.Role_Name)}
                  value={selectedRoles}
                  onChange={handleRoleChange}
                  renderTags={(value, getTagProps) =>
                    value.map((option, index) => (
                      <Chip label={option} {...getTagProps({ index })} />
                    ))
                  }
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      label="Roles"
                      variant="outlined"
                      fullWidth
                    />
                  )}
                />
              </Grid>

              <Grid item xs={6}>
                <FormControl fullWidth variant="outlined">
                  <InputLabel>User type</InputLabel>
                  <Select
                    value={formData.User_Type || ""}
                    label="User type"
                    onChange={(e) =>
                      handleInputChange("User_Type", e.target.value)
                    }
                  >
                    {userStatus &&
                      userStatus.map((status: any) => (
                        <MenuItem value={status.Status_Name} key={status.Id}>
                          {status.Status_Name}
                        </MenuItem>
                      ))}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={6}>
                <TextField
                  label="Customer"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  value={
                    selectedCustomer?.Customer_Name || data?.Customer_Name || ""
                  }
                  onClick={() => setIsCustomerModalOpen(true)}
                  onChange={(e) =>
                    handleInputChange("Customer_Id", e.target.value)
                  }
                />
              </Grid>
            </>
          )}
        </Grid>
        <Box mt={2} display="flex" justifyContent="space-between">
          {mode === "create" && (
            <Button
              variant="contained"
              color="primary"
              onClick={handleSubmit}
              sx={{ color: "#fff" }}
            >
              {" "}
              Create{" "}
            </Button>
          )}
          {mode === "edit" && (
            <Button
              variant="contained"
              color="primary"
              onClick={handleSubmit}
              sx={{ color: "#fff" }}
            >
              {" "}
              Save Changes{" "}
            </Button>
          )}
          <Button
            variant="outlined"
            sx={{ border: `1px solid ${theme.palette.primary.main}` }}
            onClick={() => navigate("/user/manage")}
          >
            Back
          </Button>
        </Box>
      </Box>
    </Layout>
  );
};

export default CRUDForm;

import React, { useEffect, useState } from "react";
import { useParams } from "react-router";
import { ContactPerson, UnifiedFormParams, Users } from "types";
import { BASE_API_URL } from "API/Base";
import CRUDForm from "./CRUDForm";
import AxiosInstance from "API/axios";

const UserUnifiedForm = () => {
  const { mode, id } = useParams<UnifiedFormParams>();
  const [apiData, setApiData] = useState<any>([]); // Initialize state for API data

  const base64Decode = (encodedStr: string) => {
    return atob(encodedStr);
  };

  const decodedId = id ? base64Decode(id) : null;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await AxiosInstance.get(
          `${BASE_API_URL}/admin/users/v1/users/${decodedId}`
        );
        const data: Users = response.data;

        setApiData(data);
        console.log("apiData", apiData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    if (mode !== "create") {
      fetchData();
    }
  }, [mode, id]);

  const createFields =
    mode === "create"
      ? [
          { label: "City", key: "City_Id", type: "modal" },
          { label: "Address", key: "Address_1" },
        ]
      : apiData.length > 0
      ? Object.keys(apiData[0])
          .filter(
            (key) =>
              ![
                "Id",
                "Business_Id",
                "IsStatus",
                "Role_Id",
                "Customer_Id",
                "User_Type",
                "Created_By",
                "Created_On",
                "Modify_By",
                "Modify_On",
              ].includes(key) // Exclude specific keys from the list
          )
          .map((key) => ({ label: key, key }))
      : [];
  return (
    <div>
      {mode && (
        <>
          <CRUDForm mode={mode} data={apiData} fields={createFields} />
        </>
      )}
    </div>
  );
};

export default UserUnifiedForm;

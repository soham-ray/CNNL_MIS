import React, { useEffect, useState } from "react";
import Sidebar from "../../Components/Sidebar";
import AxiosInstance from "../../API/axios";
import { useNavigate } from "react-router";
import {
  DataGrid,
  GridColDef,
  GridRenderCellParams,
  GridToolbar,
} from "@mui/x-data-grid";
import "../CustomerMaster/datatable.css";
import { parseISO, format } from "date-fns";
import theme from "../../theme";
import { Box, ThemeProvider } from "@mui/system";
import {
  Checkbox,
  Button,
  List,
  ListItem,
  ListItemText,
  Modal,
  Switch,
  TextField,
  Typography,
  ListItemIcon,
} from "@mui/material";
import { motion } from "framer-motion";
import toast from "react-hot-toast";
import Layout from "Components/Layout";
import { useTokenStore } from "../../Zustand/TokenStore";
import Header from "Components/Header";
import { usePagePermissions } from "Components/PagePermissions";
type Props = {};

interface WrapTextCellProps {
  value: string; // Assuming Address_1 is of type string
}

interface Role {
  Id: number;
  Role_Name: string;
  Role_Description: number;
  Is_Active: number;
  Created_By: number;
  Created_Date: null | Date;
  Updated_By: null | number;
  Updated_Date: null | Date; // Assuming the date will be a string if not null
}
export default function RolesManage({}: Props) {
  const permissions = usePagePermissions("Roles");
  const navigate = useNavigate();
  const [rows, setRows] = useState<Role[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedRow, setSelectedRow] = useState<Role | null>(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  // Function to open the delete modal
  const openDeleteModal = () => {
    setIsDeleteModalOpen(true);
  };

  // Function to close the delete modal
  const closeDeleteModal = () => {
    setIsDeleteModalOpen(false);
  };

  const get_roles = async () => {
    try {
      const response = await AxiosInstance.get("/admin/roles/v1/get-all-roles");
      const data = response.data;
      console.log(data);
      return data;
    } catch (error) {
      console.log("Error retrieving roles:", error);
      return []; // Return an empty array in case of error
    }
  };

  const handleEditClick = (roleid: number) => {
    console.log("Edit clicked");
    navigate(`/roles/edit/${roleid}`);
  };

  const getRowId = (row: Role) => row.Id;

  const formatDate = (dateString: string) => {
    const date = parseISO(dateString);
    return format(date, "M/dd/yyyy h:mm:ss a");
  };

  const WrapTextCell: React.FC<WrapTextCellProps> = ({ value }) => {
    return <div style={{ whiteSpace: "pre-wrap" }}>{value}</div>;
  };

  //allow multiple row selections
  const [selectionModel, setSelectionModel] = useState<any[]>([]);
  const handleSelectionModelChange = (newSelection: any[]) => {
    setSelectionModel(newSelection);
  };

  const deleteModalContent = (
    <Box
      sx={{ width: 400, bgcolor: "background.paper", p: 2, borderRadius: 4 }}
    >
      <Typography variant="h6">Confirm Deletion</Typography>
      <Typography>You are about to delete the following roles:</Typography>
      <List>
        {selectionModel.map((selectedRowId) => {
          const selectedRow = rows.find((row) => row.Id === selectedRowId);
          return (
            <ListItem key={selectedRowId}>
              <ListItemIcon>
                <Checkbox checked={true} />
              </ListItemIcon>
              <ListItemText primary={selectedRow?.Role_Name} />
            </ListItem>
          );
        })}
      </List>
      <div className="flex flex-row items-center justify-center gap-x-4">
        <Button
          variant="contained"
          color="secondary"
          onClick={() => {
            deleteRoles();
          }}
        >
          Confirm Delete
        </Button>
        <Button variant="contained" onClick={closeDeleteModal}>
          Cancel
        </Button>
      </div>
    </Box>
  );

  const deleteRoles = async () => {
    let deleteIds: number[] = [];
    //extract roleids from selectionModel
    selectionModel.forEach((selectedRowId) => {
      const selectedRow = rows.find((row) => row.Id === selectedRowId);
      deleteIds.push(selectedRow?.Id as number);
    });
    console.log("delete", deleteIds);
    const data = {
      Roles_Id: deleteIds,
    };
    console.log(data);
    try {
      const res = await AxiosInstance.patch(
        "/admin/roles/v1/delete-roles",
        data
      );
      if (res.status === 200) {
        closeDeleteModal();
        toast.success("Roles deleted successfully");
      }
    } catch (error) {
      console.log(error);
      toast.error("Error deleting roles");
    }
  };

  //log out current selection

  const columns: GridColDef[] = [
    { field: "Id", headerName: "ID", width: 90 },
    ...(permissions?.Update || permissions?.View
      ? [
          {
            field: "Actions",
            headerName: "Actions",
            width: 180,
            renderCell: (params: GridRenderCellParams) => (
              <div className="cellAction">
                {permissions?.Update ? (
                  <div
                    className="editButton"
                    onClick={() => {
                      handleEditClick(params.row.Id as number);
                      console.log("Role Id ", params.row.Id);
                    }}
                  >
                    Edit
                  </div>
                ) : null}
                {permissions?.View ? (
                  <div
                    className="viewButton"
                    onClick={() => {
                      handleViewClick(params.row.Id as number);
                      console.log("Role Id ", params.row.Id);
                    }}
                  >
                    View
                  </div>
                ) : null}
              </div>
            ),
          },
        ]
      : []),
    {
      field: "Role_Name",
      headerName: "Role Name",
      width: 150,
      renderCell: (params) => <WrapTextCell value={params.value} />,
    },
    {
      field: "Is_Active",
      headerName: "Status",
      width: 150,
      type: "boolean",
      //render true if 1 else render false
      valueFormatter: (params) => (params.value === 1 ? "Active" : "Inactive"),
      renderCell: (params) => (
        <WrapTextCell value={params.value === 1 ? "Active" : "Inactive"} />
      ),
    },
    {
      field: "Created_Date",
      headerName: "Created On",
      width: 180,
      renderCell: (params) => (
        <WrapTextCell
          value={params.value === null ? "null" : formatDate(params.value)}
        />
      ),
      // valueFormatter: (params) => formatDate(params.value as string),
    },
  ];

  const handleViewClick = (roleid: number) => {
    console.log("View clicked");
    navigate(`/roles/view/${roleid}`);
  };

  const buttonVariants = {
    hidden: { opacity: 0, scale: 0, transition: { duration: 0.3 } },
    visible: { opacity: 1, scale: 1, transition: { duration: 0.3 } },
  };

  //Permissions:

  useEffect(() => {
    if (permissions?.List) {
      get_roles().then((data) => {
        setRows(data);
        setLoading(false);
      });
    }
  }, [permissions]);

  return (
    <Layout>
      <div className="grid h-full px-8 pt-4 grid-rows-12">
        <div
          id="heading"
          className="flex flex-col items-start justify-end w-full row-span-2 pl-4 bg-white"
        >
          <Header title={"Manage Roles"} subtitle="" />
        </div>
        <div
          id="actions"
          className="flex flex-row items-center justify-start w-full row-span-1 pl-4 gap-x-4 "
        >
          {permissions?.Add ? (
            <Button
              variant="contained"
              sx={{ color: "#fff" }}
              onClick={() => {
                navigate("/roles/add");
              }}
            >
              Add Role
            </Button>
          ) : null}
          {permissions?.Delete ? (
            <motion.div
              variants={buttonVariants}
              initial="hidden"
              animate={selectionModel.length > 0 ? "visible" : "hidden"}
            >
              {/* //show delete button only if there is a selection */}
              <Button
                variant="contained"
                onClick={openDeleteModal}
                sx={{ color: "#fff" }}
              >
                {selectionModel.length === 1
                  ? "Delete Role"
                  : "Delete Multiple Roles"}
              </Button>
            </motion.div>
          ) : null}
          {permissions?.Update ? (
            <motion.div
              variants={buttonVariants}
              initial="hidden"
              animate={selectionModel.length === 1 ? "visible" : "hidden"}
            >
              <Button
                variant="contained"
                onClick={() => {
                  handleEditClick(selectionModel[0]);
                }}
                sx={{ color: "#fff" }}
              >
                Edit Role
              </Button>
            </motion.div>
          ) : null}
        </div>
        <div id="table" className="w-full row-span-9">
          <Box
            m="40px 0 0 0"
            height="75vh"
            sx={{
              "& .MuiDataGrid-root": {
                border: "none",
                borderBottom: `2px solid ${theme.palette.secondary.light}`,
              },

              "& .MuiDataGrid-columnHeaders": {
                backgroundColor: theme.palette.primary.main,
                borderBottom: "none",
                fontWeight: "bold",
              },
              "& .MuiDataGrid-columnHeaderTitle": {
                color: "#fff !important",
              },

              "& .MuiDataGrid-colCell": {
                color: `#fff !important`,
              },

              "& .MuiDataGrid-footerContainer": {
                display: "none",
              },
            }}
            px="16px"
          >
            <DataGrid
              rows={rows}
              columns={columns}
              loading={loading}
              getRowId={getRowId}
              autoHeight
              checkboxSelection
              rowSelectionModel={selectionModel}
              onRowSelectionModelChange={handleSelectionModelChange}
              disableRowSelectionOnClick={true}
              pagination
              initialState={{
                pagination: { paginationModel: { pageSize: 25 } },
              }}
              onCellClick={(params) => {
                if (params.field === "action" && params.row) {
                  console.log("clicked", params.row.Id);
                }
              }}
            />
          </Box>
        </div>
        <Modal
          open={isDeleteModalOpen}
          onClose={closeDeleteModal}
          aria-labelledby="confirm-delete-modal"
          aria-describedby="confirm-delete-modal-description"
          className="flex flex-row items-center justify-center"
        >
          <div className="delete-modal">{deleteModalContent}</div>
        </Modal>
      </div>
    </Layout>
  );
}

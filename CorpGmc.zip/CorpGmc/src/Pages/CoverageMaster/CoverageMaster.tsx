import { Box, Button, Modal } from "@mui/material";
import {
  DataGrid,
  GridAlignment,
  GridColDef,
  GridRenderCellParams,
  GridToolbar,
} from "@mui/x-data-grid";
import { BASE_API_URL } from "API/Base";
import AxiosInstance from "API/axios";
import Header from "Components/Header";
import Layout from "Components/Layout";
import LoadingAnimation from "Components/LoadingAnimation";
import { usePagePermissions } from "Components/PagePermissions";
import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { useNavigate } from "react-router";

type Props = {};

interface Coverages {
  Id: number;
  Coverage_Name: string;
  Coverage_Detail: string;
  Coverage_Type: string;
  Parent_Coverage_Id: number;
  Parent_Coverage_Name: string;
}

function CoverageMaster({}: Props) {
  const permissions = usePagePermissions("Coverages");
  const navigate = useNavigate();
  const [Loading, setLoading] = useState<boolean>(true);
  const [Coverages, setCoverages] = useState<Coverages[]>([]);
  const [isDeleteModalOpen, setisDeleteModalOpen] = useState<boolean>(false);
  const [selectedCoverageId, setSelectedCoverageId] = useState<number | null>(
    null
  );
  const openDeleteModel = (coverageId: number) => {
    setSelectedCoverageId(coverageId);
    setisDeleteModalOpen(true);
  };

  const closeDeleteModal = () => {
    setSelectedCoverageId(null);
    setisDeleteModalOpen(false);
  };

  const fetchCoverages = async () => {
    try {
      const res = await AxiosInstance.get(
        `${BASE_API_URL}/admin/coverages/v1/get-coverages`
      );
      const data: Coverages[] = res.data;
      setCoverages(data);
      setLoading(false);
    } catch (e) {
      console.log(e);
      setLoading(false);
    }
  };

  // check if any coverage has it as a paernt
  const handledeletecoverage = async (coverageid: number) => {
    console.log(coverageid);
    const coveragename = Coverages.find(
      (coverage) => coverage.Id === coverageid
    )?.Coverage_Name;
    const haschildren = Coverages.find(
      (coverage) => coverage.Parent_Coverage_Name === coveragename
    );
    if (haschildren) {
      toast.error("This Coverage has children, please delete them first");
    }
    try {
      const res = await AxiosInstance.delete(
        `${BASE_API_URL}/admin/coverages/v1/delete/coverage/${coverageid}`
      );
      if (res.status === 200) {
        toast.success("Coverage Deleted Successfully");
        fetchCoverages();
      }
    } catch (e) {
      console.log(e);
      toast.error("Something Went Wrong");
    }
  };

  const handleEditClick = (id: number) => {
    navigate(`/coverages/edit/${id}`);
  };

  const handleViewClick = (id: number) => {
    navigate(`/coverages/view/${id}`);
  };

  const columns: GridColDef[] = [
    {
      field: "Sr. No.",
      headerName: "Index",
      width: 70,
      headerAlign: "center",
      align: "center",
      renderCell: (params) => {
        // Find the index of the row in the rows array and add 1
        const rowIndex =
          Coverages.findIndex((row) => row.Id === params.row.Id) + 1;
        return <div>{rowIndex}</div>;
      },
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center ",
    },
    {
      field: "Coverage_Name",
      headerName: "Coverage Name",
      width: 300,
      headerAlign: "center",
      align: "center",
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center ",
    },
    ...(permissions?.Update || permissions?.View || permissions?.Delete
      ? [
          {
            field: "Actions",
            headerName: "Actions",
            headerAlign: "center" as GridAlignment, // Corrected type
            align: "center" as GridAlignment, // Corrected type
            headerClassName:
              "bg-primary text-white font-bold flex flex-row items-center",
            width: 100,
            flex: 1,
            renderCell: (params: GridRenderCellParams) => (
              <>
                {permissions?.Update && (
                  <div className="flex items-center  border border-[#00008b] rounded-lg">
                    <div
                      onClick={() => {
                        handleEditClick(params.row.Id);
                      }}
                      className="px-1.5 py-0.5 rounded-md text-[#00008b] cursor-pointer"
                    >
                      Edit
                    </div>
                  </div>
                )}
                {permissions?.Delete && (
                  <div className="flex items-center mx-2 border rounded-lg border-[#dc143c]">
                    <div
                      onClick={() => openDeleteModel(params.row.Id)}
                      className="px-1.5 py-0.5 rounded-md text-[#dc143c] cursor-pointer"
                    >
                      Delete
                    </div>
                  </div>
                )}
                {permissions?.View && (
                  <div className="flex items-center  border rounded-lg border-[#008000] ">
                    <div
                      onClick={() => {
                        handleViewClick(params.row.Id);
                      }}
                      className="px-1.5 py-0.5 rounded-md text-[#008000] cursor-pointer"
                    >
                      View
                    </div>
                  </div>
                )}
              </>
            ),
          },
        ]
      : []),
    // {
    //   field: "Coverage_Detail",
    //   headerName: "Coverage Detail",
    //   width: 200,
    //   flex: 1,
    //   headerAlign: "center",
    //   align: "center",
    //   headerClassName:
    //     "bg-primary text-white font-bold flex flex-row items-center ",
    // },
    {
      field: "Coverage_Type",
      headerName: "Input Type",
      width: 150,
      headerAlign: "center",
      align: "center",
      renderCell: (params) => {
        // Find the index of the row in the rows array and add 1
        return (
          <div>
            {params.row.Coverage_Type === "Boolean" ? "Checkbox" : "Input"}
          </div>
        );
      },
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center ",
    },
    {
      field: "Parent_Coverage_Name",
      headerName: "Parent Coverage",
      width: 200,
      flex: 1,
      headerAlign: "center",
      align: "center",
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center ",
    },
  ];

  const deleteModalContent = (
    <Box
      // sx={{ width: 400, bgcolor: "background.paper", p: 2, borderRadius: 4 }}
      className="w-[500px] h-48 bg-white rounded-lg overflow-clip"
    >
      <div className="flex flex-row items-center justify-center w-full h-1/5 bg-primary">
        <h2 id="confirm-delete-modal" className="text-lg text-white">
          Confirm Delete
        </h2>
      </div>
      <div className="flex flex-col items-center justify-center w-full text-lg h-2/5">
        <p id="confirm-delete-modal-description">
          Are you sure you want to delete this Coverage?
        </p>

        <p>
          Coverage Name :{" "}
          {
            Coverages.find((coverage) => coverage.Id === selectedCoverageId)
              ?.Coverage_Name
          }
        </p>
      </div>

      <div className="flex flex-row items-center justify-around w-full mt-4">
        <Button
          variant="outlined"
          className="mr-4"
          onClick={() => {
            closeDeleteModal();
          }}
        >
          Cancel
        </Button>
        <Button
          variant="contained"
          onClick={() => {
            if (selectedCoverageId !== null) {
              handledeletecoverage(selectedCoverageId);
              setSelectedCoverageId(null); // Reset after deletion
            }
            closeDeleteModal();
          }}
        >
          <span className="text-white">Delete</span>
        </Button>
      </div>
    </Box>
  );

  useEffect(() => {
    fetchCoverages();
  }, []);

  return (
    <Layout>
      <div className="flex flex-col items-center justify-start w-full h-full p-8 mb-16">
        <div className="flex flex-row items-center justify-start w-full">
          <Header title="Coverages" subtitle="" />
        </div>
        {Loading ? (
          <LoadingAnimation />
        ) : (
          <>
            <div className="w-full" id="actions">
              {permissions?.Add && (
                <Button
                  onClick={() => {
                    navigate("/coverages/add");
                  }}
                  sx={{ color: "#fff" }}
                  variant="contained"
                >
                  Create New Coverage
                </Button>
              )}
            </div>
            <div className="flex flex-col items-center justify-start w-full pr-12 mt-8">
              <DataGrid
                rows={Coverages}
                columns={columns}
                autoHeight
                className="w-full"
                loading={Loading}
                getRowId={(rows) => rows.Id.toString()}
                disableRowSelectionOnClick={true}
                pagination
                pageSizeOptions={[5, 10, 25, 50]}
                initialState={{
                  pagination: { paginationModel: { pageSize: 25 } },
                }}
                onCellClick={(params) => {
                  if (params.field === "action" && params.row) {
                    console.log("clicked", params.row.Id);
                  }
                }}
              />
            </div>
          </>
        )}
      </div>
      <Modal
        open={isDeleteModalOpen}
        onClose={closeDeleteModal}
        aria-labelledby="confirm-delete-modal"
        aria-describedby="confirm-delete-modal-description"
        className="flex flex-row items-center justify-center"
      >
        <div className="delete-modal">{deleteModalContent}</div>
      </Modal>
    </Layout>
  );
}

export default CoverageMaster;

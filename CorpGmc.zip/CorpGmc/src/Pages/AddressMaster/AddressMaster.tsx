import React, { useEffect, useState } from "react";
import { DataGrid, GridColDef, GridToolbar } from "@mui/x-data-grid";
import { Button } from "@mui/material";
import { Box, ThemeProvider } from "@mui/system";
import { useNavigate } from "react-router-dom";
import { BASE_API_URL } from "../../API/Base";
import theme from "../../theme";
import Header from "../../Components/Header";
import { Address, WrapTextCellProps } from "../../types";
import DeleteModal from "../../Modals/DeleteModal";
import Layout from "Components/Layout";
import { usePermission } from "Components/ActionPermission";
import toast from "react-hot-toast";
import AxiosInstance from "API/axios";
import PaginationButtons from "Components/PaginationButtons";
import { usePagePermissions } from "Components/PagePermissions";
import { AddBox, Delete, EditNote, MenuBook } from "@mui/icons-material";

const AddressMaster: React.FC = () => {
  const [rows, setRows] = useState<Address[]>([]);
  const [selectedRowId, setSelectedRowId] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);
  const [rowCount, setRowCount] = useState<number>(0);

  const navigate = useNavigate();

  // Fetch permissions for Address module
  const permissions = usePagePermissions("Address");

  // Base64 decoding function
  function base64Decode(encodedStr: string) {
    return atob(encodedStr);
  }
  function base64Encode(str: string) {
    return btoa(str);
  }

  const fetchData = async (page: number, pageSize: number) => {
    try {
      setLoading(true);

      console.log("Fetching data for page:", page, "pageSize:", pageSize);

      const response = await AxiosInstance.get(
        `${BASE_API_URL}/admin/v1/address-details`,
        {
          params: {
            page,
            per_page: pageSize,
          },
        }
      );

      console.log("Response:", response);

      if (
        !response.data ||
        !response.data.address_data ||
        response.data.total_count == null
      ) {
        console.error("Invalid response format:", response.data);
        setLoading(false);
        return;
      }

      const formattedData = response.data.address_data.map(
        (row: Address, index: number) => ({
          ...row,
          actionsID: startIndex + index + 1,
          Id: row.Id,
        })
      );

      console.log("Formatted Data:", formattedData);

      setRows(formattedData);
      setRowCount(response.data.total_count);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (permissions?.List) {
      fetchData(currentPage, pageSize);
    }
  }, [currentPage, pageSize, permissions]);

  // Calculate total pages
  const totalPages = Math.ceil(rowCount / pageSize);

  // Calculate start and end index for the visible rows
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = Math.min(currentPage * pageSize, rowCount);

  // Slice the rows array to get the visible rows
  const visibleRows = rows.slice(startIndex, endIndex);

  // Conditionally define the Action column based on permissions
  const actionColumn =
    permissions?.Update || permissions?.Delete || permissions?.View
      ? {
          field: "action",
          headerName: "Action",
          width: 220,
          renderCell: (params: any) => (
            <div className="cellAction">
              {permissions?.Update && (
                <div
                  className="editButton"
                  onClick={() => handleEdit(params.row)}
                >
                  <EditNote sx={{ fontSize: "20px" }} />
                </div>
              )}
              {permissions?.Delete && (
                <div
                  className="deleteButton"
                  onClick={() => handleDelete(params.row.Id)}
                >
                  <Delete sx={{ fontSize: "20px" }} />
                </div>
              )}
              {permissions?.View && (
                <div
                  className="viewButton"
                  onClick={() => handleView(params.row)}
                >
                  <MenuBook sx={{ fontSize: "20px" }} />
                </div>
              )}
            </div>
          ),
        }
      : undefined;

  // Columns configuration for DataGrid
  let columns: GridColDef[] = [
    {
      field: "actionsID",
      headerName: "ID",
      width: 70,
      headerClassName: "super-app-theme--header",
    },
    ...(actionColumn ? [actionColumn] : []),
    {
      field: "Address_1",
      headerName: "Address",
      width: 350,
      headerClassName: "super-app-theme--header",

      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value ? <WrapTextCell value={params.value} /> : "N/A"}
        </div>
      ),
    },
    {
      field: "City_Name",
      headerName: "City",
      width: 200,
      headerClassName: "super-app-theme--header",

      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
    {
      field: "State_Name",
      headerName: "State",
      width: 150,
      headerClassName: "super-app-theme--header",

      renderCell: (params) => (
        <div className={`cellWithStatus ${params.value ? "" : "inactive"}`}>
          {params.value || "N/A"}
        </div>
      ),
    },
  ];

  // Function to get row ID for DataGrid
  const getRowId = (row: Address) => row.Id;

  // Component to wrap text cells and enable white-space wrapping
  const WrapTextCell: React.FC<WrapTextCellProps> = ({ value }) => {
    return <div style={{ whiteSpace: "pre-wrap" }}>{value}</div>;
  };

  // Function to handle creating a new address
  const handleCreate = () => {
    navigate("/address-master/form/create");
    console.log("create");
  };

  // Function to handle editing an address
  const handleEdit = (row: any) => {
    const encodedId = base64Encode(row.Id);
    navigate(`/address-master/form/edit/${encodedId}`);
  };

  // Function to handle viewing an address
  const handleView = (row: any) => {
    const encodedId = base64Encode(row.Id);
    navigate(`/address-master/form/view/${encodedId}`);
  };

  // Function to handle deleting an address
  const handleDelete = (id: string) => {
    const encodedId = base64Encode(id);
    setIsDeleteModalOpen(true);
    setSelectedRowId(encodedId);
    console.log(id);
  };

  // Function to handle cancelling the delete operation
  const handleDeleteCancel = () => {
    setIsDeleteModalOpen(false);
  };

  // Function to handle confirming the delete operation
  const handleDeleteConfirm = async () => {
    try {
      const decodedId = selectedRowId ? base64Decode(selectedRowId) : null;
      const response = await AxiosInstance.delete(
        `${BASE_API_URL}/admin/address-details/${decodedId}`
      );

      if (response.data) {
        setIsDeleteModalOpen(false);
        setRows((prevRows) =>
          prevRows.filter((row: any) => row.Id.toString() !== decodedId)
        );
        toast.success("Data deleted successfully!");
      } else {
        toast.error("Data deletion failed");
      }
    } catch (error) {
      toast.error("Error deleting data");
      setIsDeleteModalOpen(false);
    }
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    // Add logic to fetch data for the new page or perform any other actions
  };

  return (
    <Layout>
      <ThemeProvider theme={theme}>
        <div className="datatable">
          <div className="datatableTitle">
            <Header title="Address Master" subtitle="" />
            <div className="flex space-x-2">
              {permissions?.Add && (
                <Button className="link" onClick={handleCreate}>
                  <AddBox sx={{ fontSize: "40px" }} />
                </Button>
              )}
            </div>
          </div>
          <Box
            width={"1100px"}
            margin={"auto"}
            sx={{
              "& .MuiDataGrid-root": {
                border: "none",
                borderBottom: `2px solid ${theme.palette.secondary.light}`,
              },

              "& .MuiDataGrid-columnHeaders": {
                backgroundColor: theme.palette.primary.main,
                borderBottom: "none",
                fontWeight: "bold",
              },
              "& .MuiDataGrid-columnHeaderTitle": {
                color: "#fff !important",
              },

              "& .MuiDataGrid-colCell": {
                color: `#fff !important`,
              },

              "& .MuiDataGrid-footerContainer": {
                display: "none",
              },
            }}
          >
            <DataGrid
              rows={rows}
              columns={columns}
              autoHeight={true}
              loading={loading}
              getRowId={getRowId}
              // density="comfortable"
            />
          </Box>

          <PaginationButtons
            currentPage={currentPage}
            totalPages={totalPages}
            handlePageChange={handlePageChange}
          />
        </div>

        <DeleteModal
          isOpen={isDeleteModalOpen}
          onClose={handleDeleteCancel}
          onConfirm={handleDeleteConfirm}
          title="Confirm Deletion"
          message="Are you sure you want to delete this data?"
        />
      </ThemeProvider>
    </Layout>
  );
};

export default AddressMaster;

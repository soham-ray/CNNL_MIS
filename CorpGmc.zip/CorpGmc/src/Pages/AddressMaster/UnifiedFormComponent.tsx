// UnifiedFormComponent.tsx
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { BASE_API_URL } from "../../API/Base";
import { UnifiedFormParams } from "../../types";
import CRUDForm from "./CRUDForm";
import AxiosInstance from "API/axios";
import axios from "axios";

const UnifiedFormComponent: React.FC = () => {
  const { mode, id } = useParams<UnifiedFormParams>();
  const [apiData, setApiData] = useState<any>([]);
  const [isCityModalOpen, setIsCityModalOpen] = useState<boolean>(false);
  const [selectedCity, setSelectedCity] = useState<any | undefined>(null);

  // Base64 decoding function
  function base64Decode(encodedStr: string) {
    return atob(encodedStr);
  }

  const decodedId = id ? base64Decode(id) : null;
  console.log(decodedId);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${BASE_API_URL}/admin/v1/address-details/${decodedId}`
        );

        const data = response.data;
        console.log(data);

        // Filter data based on the provided id
        const filteredData = decodedId
          ? data.filter((item: any) => item.Id === Number(decodedId))
          : data;

        setApiData(filteredData);
        console.log(apiData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    if (mode !== "create") {
      fetchData();
    }
  }, [mode, id]);

  const handleCityModalOpen = () => {
    setIsCityModalOpen(true);
  };

  const handleCityModalClose = () => {
    setIsCityModalOpen(false);
  };

  const handleCitySelect = (cityData: any) => {
    console.log(cityData);
    setSelectedCity(cityData);
    handleCityModalClose();
  };

  const createFields =
    mode === "create"
      ? [
          { label: "City", key: "City_Id", type: "modal" },
          { label: "Address", key: "Address_1" },
        ]
      : apiData.length > 0
      ? Object.keys(apiData[0])
          .filter(
            (key) =>
              ![
                "Id",
                "Created_By",
                "Modify_By",
                "Created_On",
                "Modify_On",
              ].includes(key)
          )
          .map((key) => ({ label: key, key }))
      : [];

  return (
    <div>
      {mode && (
        <>
          <CRUDForm
            mode={mode}
            data={apiData.find((item: any) => item.Id === Number(decodedId))} // Find the specific item
            fields={createFields}
          />
        </>
      )}
    </div>
  );
};

export default UnifiedFormComponent;

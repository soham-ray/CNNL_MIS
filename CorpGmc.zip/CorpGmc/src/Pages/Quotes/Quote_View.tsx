import {
  Box,
  Grid,
  Paper,
  Tab,
  Tabs,
  TextField,
  Typography,
} from "@mui/material";
import { DataGrid, GridColDef, GridToolbar } from "@mui/x-data-grid";
import { BASE_API_URL } from "API/Base";
import AxiosInstance from "API/axios";
import Header from "Components/Header";
import Layout from "Components/Layout";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router";
import { GMCQuoteOutputModel, QuoteDataModel } from "types";

type Props = {};

// Previous_Policy_Start: Date;
// Previous_Policy_End: Date;
// Members_Inception: int;
// Members_Till_Date: int;
// Claims_Quantity: int;
// Last_Claim_Date: Date;
// Claim_Amount: int;
// Claim_Outstanding: int;
interface QuoteViewModel {
  Id: number;
  QuoteNumber: number;
  ProductId: number;
  ProductName: string;
  CustomerId: number;
  CustomerName: string;
  FamilyId: number;
  FamilyType: string;
  QuoteDate: Date; // You may need to adjust the Date type to match your needs
  isRenewal: boolean;
  Previous_Insurance_Company: string;
  Previous_Policy_Start: Date;
  Previous_Policy_End: Date;
  Members_Inception: number;
  Members_Till_Date: number;
  Claims_Quantity: number;
  Last_Claim_Date: Date;
  Claim_Amount: number;
  Claim_Outstanding: number;
}

interface TabPanelProps {
  children?: React.ReactNode;
  index: any;
  value: any;
}
interface Coverages {
  CoverageId: number;
  CoverageName: string;
  InputType: string;
  Value: string;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && <Box p={3}>{children}</Box>}
    </div>
  );
}

function Quote_View({}: Props) {
  const { id } = useParams<{ id?: string }>();
  const QuoteNumber = parseInt(id ?? "");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [QuoteDetails, setQuoteDetails] = useState<QuoteViewModel | null>(null);
  const [QuoteData, setQuoteData] = useState<GMCQuoteOutputModel | null>(null);
  const [Coverages, setCoverages] = useState<Coverages[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [quoteDetailsRes, quoteDataRes, coveragesRes] = await Promise.all(
          [
            AxiosInstance.get(
              `${BASE_API_URL}/admin/quotes/Master/get-quote-details-by-qn/${QuoteNumber}`
            ),
            AxiosInstance.get(
              `${BASE_API_URL}/admin/quotes/gmc-quote/v1/get-quote-data-by-quote-number?QuoteNumber=${QuoteNumber}`
            ),
            AxiosInstance.get(
              `${BASE_API_URL}/admin/quotes/gmc-quote/v1/get-coverage-data-by-quote-number?QuoteNumber=${QuoteNumber}`
            ),
          ]
        );

        setQuoteDetails(quoteDetailsRes.data);
        setQuoteData(quoteDataRes.data);
        setCoverages(coveragesRes.data);
      } catch (err) {
        setError("Failed to fetch data");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [QuoteNumber]);

  const cols: GridColDef[] = [
    {
      field: "QuoteNumber",
      headerName: "Quote Number",
      width: 100,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeNumber",
      headerName: "Employee Number",
      width: 200,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeName",
      headerName: "Employee Name",
      width: 300,
      flex: 1,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeGender",
      headerName: "Gender",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeDOB",
      headerName: "DOB",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeRelation",
      headerName: "Relation",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeSum",
      headerName: "Sum Assured",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
    {
      field: "EmployeeAge",
      headerName: "Age",
      flex: 1,
      width: 200,
      headerClassName:
        "bg-primary text-white font-bold flex flex-row items-center justify-center",
    },
  ];

  const [tabValue, setTabValue] = useState(0);
  const handleTabChange = (
    event: React.SyntheticEvent,
    newValue: number
  ): void => {
    setTabValue(newValue);
  };
  return (
    <Layout>
      <div className="w-full h-full px-8 pt-8 overflow-x-hidden">
        <Header subtitle={""} title="View Quote Details" />
        <Box sx={{ width: "100%", typography: "body1" }}>
          <Tabs
            value={tabValue}
            onChange={handleTabChange}
            aria-label="quote details tabs"
          >
            <Tab label="Quote Details" />
            <Tab label="Quote Data" />
          </Tabs>
          <TabPanel value={tabValue} index={0}>
            {/* {QuoteDetails?.isRenewal ? ( */}
            {/* ) : ( */}
            {QuoteDetails?.isRenewal ? (
              <Paper
                elevation={5}
                className="flex flex-row w-full p-2 rounded-3xl"
              >
                <div className="flex flex-col w-1/3 gap-y-2">
                  <Typography className="text-2xl text-primary" variant="h6">
                    Quote Details
                  </Typography>

                  <Typography className="text-2xl">
                    <span className="text-primary">Quote Number</span>:{" "}
                    {QuoteDetails?.QuoteNumber}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Quote Type</span>:{" "}
                    {QuoteDetails?.isRenewal ? "Renewal" : "Fresh"}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Quote Date</span>:{" "}
                    {QuoteDetails?.QuoteDate.toString()}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Customer Name</span>:{" "}
                    {QuoteDetails?.CustomerName}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Product Name</span>:{" "}
                    {QuoteDetails?.ProductName}
                  </Typography>
                </div>
                <div className="flex flex-col w-1/3 gap-y-2">
                  <Typography className="text-2xl text-primary" variant="h6">
                    Previous Insurance Details
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">
                      Previous Insurance Company
                    </span>
                    : {QuoteDetails?.Previous_Insurance_Company}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Previous Policy Start</span>:{" "}
                    {QuoteDetails?.Previous_Policy_Start.toString()}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Previous Policy End</span>:{" "}
                    {QuoteDetails?.Previous_Policy_End.toString()}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Members Inception</span>:{" "}
                    {QuoteDetails?.Members_Inception}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Members Till Date</span>:{" "}
                    {QuoteDetails?.Members_Till_Date}
                  </Typography>
                </div>
                <div className="flex flex-col w-1/3 gap-y-2">
                  <Typography className="text-2xl text-primary" variant="h6">
                    Claim Details
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">
                      No. of Claims in Previous Policy
                    </span>
                    : {QuoteDetails?.Claims_Quantity}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Last Claim Date</span>:{" "}
                    {QuoteDetails?.Last_Claim_Date.toString()}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">
                      Re-imbursed Claims Amount
                    </span>
                    : {QuoteDetails?.Claim_Amount}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">
                      Outstanding Claims Amount
                    </span>
                    : {QuoteDetails?.Claim_Outstanding}
                  </Typography>
                </div>
              </Paper>
            ) : (
              <Paper
                elevation={5}
                className="flex flex-row w-full p-2 rounded-3xl"
                // sx={{ p: 2, display: "flex", flexDirection: "row", gap: 2 }}
              >
                <div className="flex flex-col w-1/2 gap-y-2">
                  <Typography className="text-2xl text-primary" variant="h6">
                    Quote Details
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Quote Number</span>:{" "}
                    {QuoteDetails?.QuoteNumber}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Quote Type</span>:{" "}
                    {QuoteDetails?.isRenewal ? "Renewal" : "Fresh"}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Quote Date</span>:{" "}
                    {QuoteDetails?.QuoteDate.toString()}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Customer Name</span>:{" "}
                    {QuoteDetails?.CustomerName}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Product Name</span>:{" "}
                    {QuoteDetails?.ProductName}
                  </Typography>
                  <Typography className="text-2xl">
                    <span className="text-primary">Family Type</span>:{" "}
                    {QuoteDetails?.FamilyType}
                  </Typography>
                </div>
                <div className="flex flex-col w-1/2 gap-y-2">
                  <Typography className="text-2xl text-primary" variant="h6">
                    Coverages
                  </Typography>
                  <div className="flex flex-col gap-y-2">
                    {Coverages.map((coverage) => (
                      <div className="flex flex-row gap-x-2">
                        <Typography className="text-2xl text-primary">
                          {coverage.CoverageName} :{" "}
                        </Typography>
                        <Typography className="text-2xl">
                          {coverage.InputType === "Boolean"
                            ? coverage.Value.toLowerCase() === "true"
                              ? "True"
                              : "False"
                            : coverage.Value}
                        </Typography>
                      </div>
                    ))}
                  </div>
                </div>
              </Paper>
            )}
          </TabPanel>
          <TabPanel value={tabValue} index={1}>
            <div className="w-full h-full">
              <DataGrid
                className="w-full"
                rows={QuoteData?.QuoteData ?? []}
                columns={cols}
                getRowId={(row: QuoteDataModel) => row.Id}
                autoHeight
                slots={{
                  toolbar: GridToolbar,
                }}
                pagination
                pageSizeOptions={[5, 10]}
                initialState={{
                  pagination: { paginationModel: { pageSize: 5 } },
                }}
                onCellClick={(params) => {
                  if (params.field === "action" && params.row) {
                    console.log("clicked", params.row.Id);
                  }
                }}
              />
            </div>
          </TabPanel>
        </Box>
      </div>
    </Layout>
  );
}

export default Quote_View;

import { Button, CircularProgress, Grid, TextField } from "@mui/material";
import { Box } from "@mui/system";
import { BASE_API_URL } from "API/Base";
import AxiosInstance from "API/axios";
import Header from "Components/Header";
import Layout from "Components/Layout";
import React, { useEffect, useState } from "react";
import toast from "react-hot-toast";
import { useNavigate } from "react-router";
import theme from "theme";
import { CRUDFormPageProps } from "types";
const CRUDForm: React.FC<CRUDFormPageProps> = ({ mode, data, fields }) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [isValidForm, setIsValidForm] = useState<boolean>(true);
  const [editedValues, setEditedValues] = useState<any>({});
  const [formData, setFormData] = useState({
    Id: "",
    Name: "",
    Designation: "",
    Mobile_1: "",
    Mobile_2: "",
    Phone_1: "",
    Extn_No: "",
    Email_Id: "",
  });
  const [errors, setErrors] = useState({
    Name: "",
    Designation: "",
    Mobile_1: "",
    Mobile_2: "",
    Phone_1: "",
    Extn_No: "",
    Email_Id: "",
  });
  const navigate = useNavigate();

  useEffect(() => {
    if (mode === "edit" && data) {
      setEditedValues(data);
      setFormData({
        Id: data.Id,
        Name: data.CP_Name,
        Designation: data.CP_Designation,
        Mobile_1: data.CP_Mobile_1,
        Mobile_2: data.CP_Mobile_2,
        Phone_1: data.CP_Phone_1,
        Extn_No: data.CP_Extn_No,
        Email_Id: data.CP_Email_Id,
      });
    }
  }, [mode, data]);

  console.log(data);

  const validateForm = async () => {
    let isValid = true;
    const newErrors = {
      Name: "",
      Designation: "",
      Mobile_1: "",
      Mobile_2: "",
      Phone_1: "",
      Extn_No: "",
      Email_Id: "",
    };

    if (!formData.Name.trim()) {
      newErrors.Name = "Name is required";
      isValid = false;
    } else if (formData.Name.length < 3) {
      newErrors.Name = "Name must be at least 3 characters long";
      isValid = false;
    }

    if (!formData.Designation.trim()) {
      newErrors.Designation = "Designation is required";
      isValid = false;
    }

    if (!formData.Mobile_1.trim()) {
      newErrors.Mobile_1 = "Mobile is required";
      isValid = false;
    } else if (!/^[789]\d{9}$/.test(formData.Mobile_1.trim())) {
      newErrors.Mobile_1 = "Invalid mobile number";
      isValid = false;
    }

    if (!formData.Email_Id.trim()) {
      newErrors.Email_Id = "Email is required";
      isValid = false;
    } else if (!/\S+@\S+\.\S+/.test(formData.Email_Id.trim())) {
      newErrors.Email_Id = "Invalid email format";
      isValid = false;
    }

    setIsValidForm(isValid);
    setErrors(newErrors);
    return isValid;
  };
  const handleSubmit = async () => {
    if (await validateForm()) {
      try {
        if (mode === "create") {
          const data = {
            Name: formData.Name,
            Designation: formData.Designation,
            Mobile_1: formData.Mobile_1,
            Mobile_2: formData.Mobile_2,
            Phone_1: formData.Phone_1,
            Extn_No: formData.Extn_No,
            Email_Id: formData.Email_Id,
          };

          console.log(data);
          const response = await AxiosInstance.post(
            `${BASE_API_URL}/admin/v1/contact-person`,
            data
          );

          if (response.data) {
            toast.success("Record Added Successfully");
            setFormData({
              Id: "",
              Name: "",
              Designation: "",
              Mobile_1: "",
              Mobile_2: "",
              Phone_1: "",
              Extn_No: "",
              Email_Id: "",
            });
          } else {
            toast.error("Something went wrong");
          }
        } else if (mode === "edit") {
          const data = {
            Name: editedValues.Name || formData.Name,
            Designation: editedValues.Designation || formData.Designation,
            Mobile_1: editedValues.Mobile_1 || formData.Mobile_1,
            Mobile_2: editedValues.Mobile_2 || formData.Mobile_2,
            Phone_1: editedValues.Phone_1 || formData.Phone_1,
            Extn_No: editedValues.Extn_No || formData.Extn_No,
            Email_Id: editedValues.Email_Id || formData.Email_Id,
          };

          console.log(data);
          const response = await AxiosInstance.put(
            `${BASE_API_URL}/admin/v1/contact-person/${editedValues.Id}`,
            data
          );

          if (response.data) {
            toast.success("Record Updated Successfully");
          } else {
            toast.error("Something went wrong");
          }
        }
      } catch (error: any) {
        if (error.response) {
          toast.error("Error response details:", error.response.data);
          if (error.response.status === 400) {
            toast.error(error.response.data.detail || "Bad Request");
          } else {
            toast.error("Server Error");
          }
        } else if (error.request) {
          toast.error("No response received from the server");
        } else {
          toast.error("Error setting up the request");
        }
      }
    } else {
      return;
    }
  };

  const handleInputChange = (field: string, value: string | any) => {
    if (typeof value === "object" && value !== null) {
      // Handle the case when a value is selected from the modal
      setFormData((prevData) => ({
        ...prevData,
        [field]: value.Id, // Assuming the selected value has an 'Id' property
      }));

      setEditedValues((prevValues: any) => ({
        ...prevValues,
        [field]: value,
      }));
    } else {
      // Handle the case when the value is directly entered in the input field
      setFormData((prevData) => ({
        ...prevData,
        [field]: value,
      }));
      setEditedValues((prevValues: any) => ({
        ...prevValues,
        [field]: value,
      }));
    }
  };

  return (
    <Layout>
      {loading && (
        <Box
          sx={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
        >
          <CircularProgress size={50} />
        </Box>
      )}
      <Box sx={{ width: "80%", margin: "50px auto" }}>
        <Header
          title={
            mode === "view"
              ? "View contact person details"
              : mode === "edit"
              ? "Edit contact person details"
              : mode === "create"
              ? "Create new contact person "
              : ""
          }
          subtitle={""}
        />
        <Grid container spacing={2}>
          {mode === "view" && (
            <>
              <Grid container spacing={2}>
                {fields.map(({ label, key, type }) => (
                  <Grid item xs={6} key={key}>
                    <TextField
                      key={key}
                      label={label}
                      variant="outlined"
                      fullWidth
                      margin="normal"
                      value={data[key] || ""}
                      sx={{ marginBottom: "16px" }}
                    />
                  </Grid>
                ))}
              </Grid>
            </>
          )}
          {mode === "create" && (
            <>
              <Grid item xs={6}>
                <TextField
                  label="Name"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  required
                  value={formData.Name}
                  onChange={(e) => handleInputChange("Name", e.target.value)}
                  sx={{ marginBottom: "16px" }}
                  error={!!errors.Name}
                  helperText={errors.Name}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Designation"
                  variant="outlined"
                  fullWidth
                  required
                  margin="normal"
                  value={formData.Designation}
                  onChange={(e) =>
                    handleInputChange("Designation", e.target.value)
                  }
                  sx={{ marginBottom: "16px" }}
                  error={!!errors.Designation}
                  helperText={errors.Designation}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Mobile Number"
                  variant="outlined"
                  fullWidth
                  type="number"
                  required
                  margin="normal"
                  value={formData.Mobile_1}
                  onChange={(e) =>
                    handleInputChange("Mobile_1", e.target.value)
                  }
                  sx={{ marginBottom: "16px" }}
                  error={!!errors.Mobile_1}
                  helperText={errors.Mobile_1}
                />
              </Grid>

              <Grid item xs={6}>
                <TextField
                  label="Alternative Mobile Number"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  value={formData.Mobile_2}
                  onChange={(e) =>
                    handleInputChange("Mobile_2", e.target.value)
                  }
                  sx={{ marginBottom: "16px" }}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Phone Number"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  value={formData.Phone_1}
                  onChange={(e) => handleInputChange("Phone_1", e.target.value)}
                  sx={{ marginBottom: "16px" }}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Extn No"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  value={formData.Extn_No}
                  onChange={(e) => handleInputChange("Extn_No", e.target.value)}
                  sx={{ marginBottom: "16px" }}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Email"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  type="email"
                  required
                  value={formData.Email_Id}
                  onChange={(e) =>
                    handleInputChange("Email_Id", e.target.value)
                  }
                  sx={{ marginBottom: "16px" }}
                  error={!!errors.Email_Id}
                  helperText={errors.Email_Id}
                />
              </Grid>
            </>
          )}
          {mode === "edit" && (
            <>
              <Grid item xs={6}>
                <TextField
                  label="Name"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  required
                  value={formData.Name}
                  onChange={(e) => handleInputChange("Name", e.target.value)}
                  sx={{ marginBottom: "16px" }}
                  error={!!errors.Name}
                  helperText={errors.Name}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Designation"
                  variant="outlined"
                  fullWidth
                  required
                  margin="normal"
                  value={formData.Designation}
                  onChange={(e) =>
                    handleInputChange("Designation", e.target.value)
                  }
                  sx={{ marginBottom: "16px" }}
                  error={!!errors.Designation}
                  helperText={errors.Designation}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Mobile Number"
                  variant="outlined"
                  fullWidth
                  required
                  margin="normal"
                  value={formData.Mobile_1}
                  onChange={(e) =>
                    handleInputChange("Mobile_1", e.target.value)
                  }
                  sx={{ marginBottom: "16px" }}
                  error={!!errors.Mobile_1}
                  helperText={errors.Mobile_1}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Alternative Mobile Number"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  value={formData.Mobile_2}
                  onChange={(e) =>
                    handleInputChange("Mobile_2", e.target.value)
                  }
                  sx={{ marginBottom: "16px" }}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Phone Number"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  value={formData.Phone_1}
                  onChange={(e) => handleInputChange("Phone_1", e.target.value)}
                  sx={{ marginBottom: "16px" }}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Extn No"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  value={formData.Extn_No}
                  onChange={(e) => handleInputChange("Extn_No", e.target.value)}
                  sx={{ marginBottom: "16px" }}
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Email"
                  variant="outlined"
                  fullWidth
                  margin="normal"
                  required
                  value={formData.Email_Id}
                  onChange={(e) =>
                    handleInputChange("Email_Id", e.target.value)
                  }
                  sx={{ marginBottom: "16px" }}
                  error={!!errors.Email_Id}
                  helperText={errors.Email_Id}
                />
              </Grid>
            </>
          )}
        </Grid>
        <Box mt={2} display="flex" justifyContent="space-between">
          {mode === "create" && (
            <Button
              variant="contained"
              color="primary"
              onClick={handleSubmit}
              sx={{ color: "white" }}
            >
              {" "}
              Create{" "}
            </Button>
          )}
          {mode === "edit" && (
            <Button
              variant="contained"
              color="primary"
              onClick={handleSubmit}
              sx={{ color: "white" }}
            >
              {" "}
              Save Changes{" "}
            </Button>
          )}
          <Button
            variant="outlined"
            sx={{ border: `1px solid ${theme.palette.primary.main}` }}
            onClick={() => navigate("/contact-person")}
          >
            Back
          </Button>
        </Box>
      </Box>
    </Layout>
  );
};

export default CRUDForm;

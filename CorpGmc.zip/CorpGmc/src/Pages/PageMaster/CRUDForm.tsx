import { Action, CRUDFormPageProps, Module, Permission } from "types";
import React, { useEffect, useState } from "react";
import {
  faCoffee,
  faCogs,
  faGear,
  faHome,
  faLocation,
  faLocationPin,
  faUser,
} from "@fortawesome/free-solid-svg-icons";

import Layout from "Components/Layout";
import {
  Autocomplete,
  Box,
  Button,
  Chip,
  CircularProgress,
  FormControl,
  Grid,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import Header from "Components/Header";
import { BASE_API_URL } from "API/Base";
import AxiosInstance from "API/axios";
import theme from "theme";
import { Navigate, useNavigate } from "react-router";
import { IconDefinition } from "@fortawesome/free-solid-svg-icons";
import IconPicker from "Components/IconPicker";
import toast from "react-hot-toast";
import { da } from "date-fns/locale";

const CRUDForm: React.FC<CRUDFormPageProps> = ({ mode, data, fields }) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [modules, setModules] = useState<any>([]);
  const [permissions, setPermissions] = useState<any>([]);
  const [selectedPermissions, setSelectedPermissions] = useState<any>([]);
  const [selectedIcon, setSelectedIcon] = useState<IconDefinition | null>(null);
  const [selectedModule, setSelectedModule] = useState<Module | null>(null);
  const [editedValues, setEditedValues] = useState<any>({});
  const [formData, setFormData] = useState({
    Page_Name: "",
    Page_Url: "",
    Module_Id: 0,
    Sub_Module_Id: 0,
    Page_Icon: "",
    Page_Order: 0,
    IsStatus: true,
    Action_Id: [] as number[],
  });

  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await AxiosInstance.get(
          `${BASE_API_URL}/admin/modules/v1/modules-list`
        );

        const data: Module[] = response.data;
        setModules(data);

        // Create a mapping between product names and IDs
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    const fetchActions = async () => {
      try {
        setLoading(true);
        const response = await AxiosInstance.get(
          `${BASE_API_URL}/admin/modules/v1/actions`
        );
        const data = response.data;
        setPermissions(data);

        setLoading(false);
      } catch (error) {
        console.error("Error fetching data:", error);
        setLoading(false);
      }
    };

    fetchData();
    fetchActions();
  }, [mode]);

  useEffect(() => {
    if (mode === "edit" && data) {
      setEditedValues(data);
      // console.log(data);

      const foundModule = modules.find(
        (module: any) => module.Id === data.Module_Id
      );
      setFormData({
        Page_Name: data.Page_Name || "",
        Page_Url: data.Page_Url || "",
        Module_Id: data.Module_Id || "",
        Sub_Module_Id: data.Sub_Module_Id || 0,
        Page_Icon: data.Page_Icon || "",
        Page_Order: data.Page_Order || "",
        IsStatus: data.IsStatus || "",
        Action_Id: data.Action_Id || [],
      });

      setSelectedIcon(data.Page_Icon); // Set selectedIcon with the value from data
      setSelectedPermissions(data.Action_Names);
      setSelectedModule(foundModule ? foundModule.Module_Name : "");
    }
  }, [mode, data]);

  const handleIconSelect = (icon: any) => {
    setSelectedIcon(icon);
    handleInputChange("Page_Icon", icon.iconName); // Update the form data with the selected icon name
  };

  const handleInputChange = (key: string, value: any) => {
    setFormData({
      ...formData,
      [key]:
        key === "Action_Id"
          ? (value as string[]).map(Number).filter(Boolean)
          : value,
    });

    if (key === "Module_Id") {
      setSelectedModule(value);
    }
  };

  const handlePermissionsChange = (event: any, newValue: string[] | null) => {
    setSelectedPermissions(newValue || []);

    // fetch corresponding actions ids for the selected action names

    const actionIds = (newValue || []).map((actionName) => {
      const action = permissions.find(
        (permission: any) => permission.Action_Name === actionName
      );
      // console.log(action.Action_Name, action.Id);
      return action ? action.Id : null;
    });

    setFormData((prevData) => ({
      ...prevData,
      Action_Id: actionIds.filter((Id: any) => Id !== null),
    }));
  };

  const handleSubmit = async () => {
    try {
      if (mode === "create") {
        const foundModule = modules.find(
          (module: any) => module.Module_Name === formData.Module_Id
        );

        const newData = {
          Page_Name: formData.Page_Name,
          Page_Url: formData.Page_Url,
          Page_Icon: formData.Page_Icon,
          Page_Order: formData.Page_Order,
          IsStatus: !!formData.IsStatus,
          Module_Id: foundModule ? foundModule.Id : null,
          Sub_Module_Id: 0,
          Action_Id: formData.Action_Id,
        };

        const response = await AxiosInstance.post(
          `${BASE_API_URL}/admin/modules/v1/add-page`,
          newData
        );

        if (response.data) {
          toast.success("Page created successfully");
          setFormData({
            Page_Name: "",
            Page_Url: "",
            Module_Id: 0,
            Sub_Module_Id: 0,
            Page_Icon: "",
            Page_Order: 0,
            IsStatus: true,
            Action_Id: [] as number[],
          });
        }

        // console.log(newData);
      } else if (mode === "edit") {
        const foundModule = modules.find(
          (module: any) => module.Module_Name === formData.Module_Id
        );

        const newData = {
          Page_Name: formData.Page_Name,
          Page_Url: formData.Page_Url,
          Page_Icon: formData.Page_Icon,
          Page_Order: formData.Page_Order,
          IsStatus: !!formData.IsStatus,
          Module_Id: foundModule ? foundModule.Id : formData.Module_Id,
          Sub_Module_Id: 0,
          Action_Id: formData.Action_Id,
        };

        // console.log(newData);
        const response = await AxiosInstance.put(
          `${BASE_API_URL}/admin/modules/v1/page/${editedValues.Id}`,
          newData
        );

        if (response.data) {
          toast.success("Page updated successfully");
        }
      }
    } catch (error: any) {
      if (error.response) {
        if (error.response.status === 400) {
          toast.error(error.response.data.detail || "Bad Request");
        } else {
          // Handle other error status codes
          toast.error(`Server Error: ${error.response.status}`);
        }
      } else if (error.request) {
        toast.error("No response received from the server");
      } else {
        toast.error("Error setting up the request");
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      {" "}
      {loading && (
        <Box
          sx={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",

            zIndex: 1000,
          }}
        >
          <CircularProgress size={50} />
        </Box>
      )}
      <Box sx={{ width: "80%", margin: "50px auto" }}>
        <Header
          title={
            mode === "view"
              ? "View page details"
              : mode === "edit"
              ? "Edit page details"
              : mode === "create"
              ? "Create new page "
              : ""
          }
          subtitle={""}
        />

        <Grid container spacing={2}>
          {mode === "create" && (
            <>
              <Grid item xs={6}>
                <TextField
                  label="Page Name"
                  fullWidth
                  margin="normal"
                  value={formData.Page_Name}
                  onChange={(e) =>
                    handleInputChange("Page_Name", e.target.value)
                  }
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Page URL"
                  margin="normal"
                  fullWidth
                  value={formData.Page_Url}
                  onChange={(e) =>
                    handleInputChange("Page_Url", e.target.value)
                  }
                />
              </Grid>
              <Grid item xs={6}>
                <FormControl fullWidth variant="outlined" margin="normal">
                  <InputLabel>Module</InputLabel>
                  <Select
                    value={formData.Module_Id || ""}
                    label="Module"
                    onChange={(e) =>
                      handleInputChange("Module_Id", e.target.value)
                    }
                  >
                    {modules.map((module: Module) => (
                      <MenuItem
                        key={module.Module_Name} // Use a unique identifier here
                        value={module.Module_Name}
                      >
                        {module.Module_Name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={6}>
                <TextField
                  label="Page Order"
                  type="number"
                  fullWidth
                  margin="normal"
                  required
                  value={formData.Page_Order}
                  onChange={(e) =>
                    handleInputChange("Page_Order", e.target.value)
                  }
                />
              </Grid>

              <Grid item xs={6}>
                {permissions && (
                  <Autocomplete
                    multiple
                    id="permission-select"
                    options={
                      permissions?.map(
                        (permission: any) => permission.Action_Name
                      ) || []
                    }
                    value={selectedPermissions}
                    onChange={handlePermissionsChange}
                    isOptionEqualToValue={(option, value) => {
                      return option === value;
                    }}
                    renderOption={(props, option, { selected }) => (
                      <li
                        {...props}
                        style={{
                          backgroundColor: selected ? "#e0f7fa" : "white",
                        }}
                      >
                        {option}
                      </li>
                    )}
                    renderTags={(value, getTagProps) =>
                      value.map((option, index) => (
                        <Chip
                          label={option}
                          {...getTagProps({ index })}
                          sx={{ marginRight: 0.5 }}
                        />
                      ))
                    }
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Roles"
                        variant="outlined"
                        fullWidth
                        required
                        margin="normal"
                      />
                    )}
                  />
                )}
              </Grid>
              <Grid item xs={6}>
                <FormControl fullWidth variant="outlined" margin="normal">
                  <InputLabel>Status</InputLabel>
                  <Select
                    value={formData.IsStatus || ""}
                    label="Status"
                    onChange={(e) =>
                      handleInputChange("IsStatus", e.target.value)
                    }
                  >
                    <MenuItem value={"true"}>Active</MenuItem>
                    <MenuItem value={"false"}>Inactive</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <IconPicker
                  icons={[faCoffee, faHome, faUser, faLocation, faCogs]}
                  selectedIcon={selectedIcon}
                  onSelect={handleIconSelect}
                />
              </Grid>
            </>
          )}
          {mode === "edit" && (
            <>
              <Grid item xs={6}>
                <TextField
                  label="Page Name"
                  fullWidth
                  margin="normal"
                  value={formData.Page_Name || ""}
                  onChange={(e) =>
                    handleInputChange("Page_Name", e.target.value)
                  }
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  label="Page URL"
                  margin="normal"
                  fullWidth
                  value={formData.Page_Url || ""}
                  onChange={(e) =>
                    handleInputChange("Page_Url", e.target.value)
                  }
                />
              </Grid>
              <Grid item xs={6}>
                <FormControl fullWidth variant="outlined" margin="normal">
                  <InputLabel>Module</InputLabel>
                  <Select
                    value={selectedModule || ""}
                    label="Module"
                    onChange={(e) =>
                      handleInputChange("Module_Id", e.target.value)
                    }
                  >
                    {modules.map((module: Module) => (
                      <MenuItem
                        key={module.Module_Id} // Use a unique identifier here
                        value={module.Module_Name}
                      >
                        {module.Module_Name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={6}>
                <TextField
                  label="Page Order"
                  type="number"
                  fullWidth
                  margin="normal"
                  required
                  value={formData.Page_Order || ""}
                  onChange={(e) =>
                    handleInputChange("Page_Order", e.target.value)
                  }
                />
              </Grid>

              <Grid item xs={6}>
                {permissions && (
                  <Autocomplete
                    multiple
                    id="permission-select"
                    options={
                      permissions?.map(
                        (permission: any) => permission.Action_Name
                      ) || []
                    }
                    value={selectedPermissions || []}
                    onChange={handlePermissionsChange}
                    isOptionEqualToValue={(option, value) => option === value}
                    renderOption={(props, option, { selected }) => (
                      <li
                        {...props}
                        style={{
                          backgroundColor: selected ? "#e0f7fa" : "white",
                        }}
                      >
                        {option}
                      </li>
                    )}
                    renderTags={(value, getTagProps) =>
                      value.map((option, index) => (
                        <Chip
                          label={option}
                          {...getTagProps({ index })}
                          sx={{ marginRight: 0.5 }}
                        />
                      ))
                    }
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        label="Roles"
                        variant="outlined"
                        fullWidth
                        required
                        margin="normal"
                      />
                    )}
                  />
                )}
              </Grid>

              <Grid item xs={6}>
                <FormControl fullWidth variant="outlined" margin="normal">
                  <InputLabel>Status</InputLabel>
                  <Select
                    value={formData.IsStatus ? "true" : "false"}
                    label="Status"
                    onChange={(e) =>
                      handleInputChange(
                        "IsStatus",
                        e.target.value === "true" ? 1 : 0
                      )
                    }
                  >
                    <MenuItem value={"true"}>Active</MenuItem>
                    <MenuItem value={"false"}>Inactive</MenuItem>
                  </Select>
                </FormControl>
              </Grid>

              <Grid item xs={12}>
                <IconPicker
                  icons={[faCoffee, faHome, faUser, faLocationPin, faGear]}
                  selectedIcon={selectedIcon}
                  onSelect={handleIconSelect}
                />
              </Grid>
            </>
          )}

          {mode === "view" && (
            <>
              <Grid container spacing={2}>
                {fields.map(({ label, key, type }) => (
                  <Grid item xs={6} key={key}>
                    {key === "Action_Names" ? (
                      <Autocomplete
                        multiple
                        id="actions-autocomplete"
                        options={data[key] || []}
                        value={data[key] || []}
                        renderTags={(value, getTagProps) =>
                          value.map((option, index) => (
                            <Chip
                              label={option}
                              {...getTagProps({ index })}
                              sx={{ marginRight: 0.5 }}
                            />
                          ))
                        }
                        renderInput={(params) => (
                          <TextField
                            {...params}
                            label={label}
                            variant="outlined"
                            fullWidth
                            margin="normal"
                          />
                        )}
                      />
                    ) : (
                      <TextField
                        key={key}
                        label={label}
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        value={data[key] || ""}
                      />
                    )}
                  </Grid>
                ))}
              </Grid>
            </>
          )}
        </Grid>
        <Box mt={2} display="flex" justifyContent="space-between">
          {mode === "create" && (
            <Button
              variant="contained"
              sx={{ color: "#fff" }}
              onClick={handleSubmit}
            >
              {" "}
              Create{" "}
            </Button>
          )}
          {mode === "edit" && (
            <Button
              variant="contained"
              sx={{ color: "#fff" }}
              onClick={handleSubmit}
            >
              {" "}
              Save Changes{" "}
            </Button>
          )}
          <Button
            variant="outlined"
            sx={{ border: `1px solid ${theme.palette.primary.main}` }}
            onClick={() => navigate("/pages/manage")}
          >
            Back
          </Button>
        </Box>
      </Box>
    </Layout>
  );
};

export default CRUDForm;

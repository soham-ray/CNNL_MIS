import { useFocusEffect } from "@chakra-ui/react";
import { BASE_API_URL } from "API/Base";
import AxiosInstance from "API/axios";
import Module from "module";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router";
import { UnifiedFormParams } from "types";
import CRUDForm from "./CRUDForm";

const ModuleUnifiedForm = () => {
  const { mode, id } = useParams<UnifiedFormParams>();
  const [apiData, setApiData] = useState<any>([]);

  const base64Decode = (encodedStr: string) => {
    return atob(encodedStr);
  };

  const decodedId = id ? base64Decode(id) : null;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await AxiosInstance.get(
          `${BASE_API_URL}/admin/modules/v1/modules/${decodedId}`
        );

        const data: Module = response.data;
        setApiData(data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    if (mode !== "create") {
      fetchData();
    }
  }, [mode, decodedId]);

  const createFields =
    mode === "create"
      ? [
          { label: "City", key: "City_Id", type: "modal" },
          { label: "Address", key: "Address_1" },
        ]
      : apiData
      ? Object.keys(apiData)
          .filter(
            (key) =>
              ![
                "Id",
                "Action_Id",
                "Module_Id",
                "IsStatus",
                "Sub_Module_Id",
                "Created_By",
                "Created_On",
                "Modify_By",
                "Modify_On",
              ].includes(key)
          )
          .map((key) => ({ label: key, key }))
      : [];
  return (
    <div>
      {mode && ( // Check if mode exists
        <>
          <CRUDForm mode={mode} data={apiData} fields={createFields} />
        </>
      )}
    </div>
  );
};

export default ModuleUnifiedForm;

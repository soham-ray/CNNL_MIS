import { useTokenStore } from "../Zustand/TokenStore";
import axios, { AxiosRequestConfig, AxiosRequestHeaders } from "axios";
import { BASE_API_URL } from "./Base";
import { useNavigate } from "react-router";
// Create an Axios AxiosInstance
const AxiosInstance = axios.create({
  baseURL: `${BASE_API_URL}`,
  timeout: 50000,
});
interface AdaptAxiosRequestConfig extends AxiosRequestConfig {
  headers: AxiosRequestHeaders;
}
// Add a request interceptor
AxiosInstance.interceptors.request.use(
  async (config: AdaptAxiosRequestConfig) => {
    const accessToken = useTokenStore.getState().accessToken;
    if (accessToken) {
      // Type assertion here to ensure headers are correctly typed
      (config.headers as any).Authorization = `Bearer ${accessToken}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

async function refreshToken(): Promise<string> {
  try {
    const response = await axios.post(
      `${BASE_API_URL}/admin/auth/v1/refresh-token`,
      {},
      {
        headers: {
          accept: "application/json",
          "refresh-token": useTokenStore.getState().refreshToken, // Replace with actual logic to retrieve the refresh token
        },
      }
    );
    const newToken = response.data.access_token; // Adjust according to the actual response structure
    // Store the new token for future requests
    return newToken;
  } catch (error) {
    // Handle error (e.g., could not refresh token)
    throw error;
  }
}

// Add a response interceptor
AxiosInstance.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    if (error.response?.status === 401) {
      try {
        const newAccessToken = await refreshToken();
        if (newAccessToken) {
          AxiosInstance.defaults.headers.common[
            "Authorization"
          ] = `Bearer ${newAccessToken}`;
          // Update Zustand store
          useTokenStore.setState({ accessToken: newAccessToken });
          return AxiosInstance(originalRequest);
        } else {
          // Logout if refresh token failed
          logout();
        }
      } catch (error) {
        // Handle refresh token errors
        console.error("Error refreshing token:", error);
      }
    }

    return Promise.reject(error);
  }
);

// Function to logout
export const logout = () => {
  // Your implementation here
};

export const setAuthToken = (token: string) => {
  AxiosInstance.defaults.headers.common["Authorization"] = `Bearer ${token}`;
};

export default AxiosInstance;

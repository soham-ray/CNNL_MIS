import axios from "axios";
import AxiosInstance from "./axios";

interface LogData {
  Public_IP: string;
  Latitude: string;
  Longitude: string;
  Browser_used: string;
}

const getPublicIP = async () => {
  try {
    const response = await axios.get("https://api64.ipify.org?format=json");
    return response.data.ip;
  } catch (error) {
    console.error("Error fetching public IP:", error);
    return "";
  }
};

//get latitude and longitude of user
const getLatLong = async () => {
  try {
    const response = await axios.get("https://ipapi.co/json/");
    const latitude: string = response.data.latitude;
    const longitude: string = response.data.longitude;
    return { latitude, longitude };
  } catch (error) {
    console.error("Error fetching public IP:", error);
    return "";
  }
};

const getBrowserName = () => {
  const userAgent = navigator.userAgent;
  if (userAgent.includes("Chrome")) {
    return "Google Chrome";
  } else if (userAgent.includes("Firefox")) {
    return "Mozilla Firefox";
  } else if (userAgent.includes("Safari")) {
    return "Apple Safari";
  } else if (userAgent.includes("Edge")) {
    return "Microsoft Edge";
  } else {
    return "Unknown";
  }
};

export const Update_Login_Logs = async () => {
  try {
    const { latitude, longitude } = (await getLatLong()) as {
      latitude: string;
      longitude: string;
    };
    const publicIP = await getPublicIP();
    const browserName = getBrowserName();
    const data: LogData = {
      Public_IP: publicIP.toString(),
      Latitude: latitude.toString(),
      Longitude: longitude.toString(),
      Browser_used: browserName.toString(),
    };
    const res = await AxiosInstance.post(
      "/admin/auth/v1/update-login-logs",
      data
    );
    console.log(res);
  } catch (error) {
    console.log("Error updating login logs:", error);
  }
};

export const update_logout_logs = async () => {
  const res = await AxiosInstance.get("/admin/auth/v1/update-logout-logs");
};

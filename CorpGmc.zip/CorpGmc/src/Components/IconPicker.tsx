// IconPicker.tsx
import React from "react";
import { IconDefinition } from "@fortawesome/fontawesome-svg-core";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { FormControl, InputLabel, MenuItem, Select, Box } from "@mui/material";

interface IconPickerProps {
  icons: IconDefinition[];
  selectedIcon: IconDefinition | null;
  onSelect: (icon: IconDefinition) => void;
}

const IconPicker: React.FC<IconPickerProps> = ({
  icons,
  selectedIcon,
  onSelect,
}) => {
  return (
    <Box>
      <FormControl fullWidth variant="outlined" margin="normal">
        <InputLabel>Icon Picker</InputLabel>
        <Select
          value={selectedIcon?.iconName || selectedIcon || ""}
          onChange={(e) => {
            const selectedIconName = e.target.value as string;
            const selected = icons.find(
              (icon) => icon.iconName === selectedIconName
            );
            if (selected) {
              onSelect(selected);
            }
          }}
          label="Icon Picker"
        >
          {icons.map((icon, index) => (
            <MenuItem key={index} value={icon.iconName}>
              <FontAwesomeIcon icon={icon} style={{ marginRight: "8px" }} />
              {icon.iconName}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Box>
  );
};

export default IconPicker;

// usePermission.tsx

import { useEffect, useState } from "react";
import { useTokenStore } from "../Zustand/TokenStore";

type ActionName = "List" | "Add" | "Update" | "Delete" | "View";

export const usePermission = (moduleName: string, actionName: ActionName) => {
  const [hasPermission, setHasPermission] = useState<boolean>(false);
  const authData = useTokenStore.getState().AuthData;

  useEffect(() => {
    const modulePermissions = authData?.Modules.find(
      (module) => module.Module_Name === moduleName
    )?.Pages[0]?.Permissions;

    const actionPermission = modulePermissions?.Actions.find(
      (action) => action.ActionName === actionName
    )?.Status;

    setHasPermission(!!actionPermission);
  }, [authData, moduleName, actionName]);

  return hasPermission;
};

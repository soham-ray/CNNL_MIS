/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#416788",
        secondary: "#cbd8f1",
        secondary_shade: "#b3bed4",
        blue: "#395b78",

        // "light-white": "rgba(255,255,255,0.17)",
      },
    },
  },
  plugins: [],
};
